# Scripts

Utility and analysis scripts for the pipeline.

## Structure

```
scripts/
├── check_unique_questions.py  # Check for unique questions
└── validation_evaluation.py    # Validation and evaluation scripts
```

## Available Scripts

### check_unique_questions.py
- Checks input CSV for unique questions
- Identifies duplicates and potential issues
- Helps ensure data quality

### validation_evaluation.py
- Validates pipeline outputs
- Performs evaluation of generated answers
- Includes scoring and quality assessment

## Usage

```bash
# Check for unique questions
python check_unique_questions.py input.csv

# Run validation and evaluation
python validation_evaluation.py results.csv
```

## Key Features

- **Data quality**: Ensures input data integrity
- **Validation**: Checks pipeline outputs for correctness
- **Evaluation**: Assesses answer quality and relevance
- **Reporting**: Provides detailed analysis and metrics