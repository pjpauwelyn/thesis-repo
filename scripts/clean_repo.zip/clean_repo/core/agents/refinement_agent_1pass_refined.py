# agents/refinement_agent_1pass_refined.py

from core.agents.base_refinement_agent import BaseRefinementAgent
from core.utils.data_models import DynamicOntology, DocumentAssessment, RefinedContext
from core.utils.openalex_client import OpenAlexClient, format_reference_from_metadata
from typing import List, Dict, Any, Optional
import re
import json
import logging

class RefinementAgent1PassRefined(BaseRefinementAgent):
    def __init__(self, llm, prompt_dir: str = "prompts/refinement"):
        super().__init__("RefinementAgent1PassRefined", llm, prompt_dir)
        
    def process_context(
        self,
        question: str,
        structured_context: str,
        ontology: Optional[DynamicOntology] = None,
        include_ontology: bool = True,
        aql_results_str: Optional[str] = None,
        context_filter: str = "full"
    ) -> RefinedContext:
        # use aql-only approach - llm extracts both findings and references
        documents = []
        self.logger.info("using aql-only approach - llm extracts both findings and references")
        
        if not documents:
            if not aql_results_str:
                return self._create_empty_context(question, ontology)
        
        # build the compact refinement prompt
        prompt = self._build_refined_prompt(question, documents, ontology, include_ontology, aql_results_str)
        
        # log prompt statistics
        prompt_length = len(prompt)
        self.logger.info(f"refinement prompt statistics:")
        self.logger.info(f"prompt length: {prompt_length} characters")
        self.logger.info(f"estimated tokens: ~{prompt_length // 4} tokens")
        
        # save raw prompt to debug log file
        debug_logger = logging.getLogger('raw_prompts')
        debug_logger.debug(f"refinement raw prompt logged to debug file: {prompt[:200]}...")
        debug_logger.debug(f"full prompt:\n{prompt}")
        
        self.logger.info("raw refinement prompt logged to 'raw_prompts_debug.log'")
        
        # get text context directly from llm
        refined_text_context = self._get_refined_context_from_llm(prompt)
        
        # validate context size
        context_length = len(refined_text_context)
        estimated_tokens = context_length // 4
        self.logger.info(f"refined context statistics:")
        self.logger.info(f"context length: {context_length} characters")
        self.logger.info(f"estimated tokens: ~{estimated_tokens} tokens")
        
        # check if context is within target range
        if 1500 <= estimated_tokens <= 5000:
            self.logger.info("context size within target range (1500-5000 tokens)")
        elif estimated_tokens > 5000:
            self.logger.warning(f"context exceeds target size: {estimated_tokens} tokens")
        else:
            self.logger.warning(f"context below target size: {estimated_tokens} tokens")
        
        # create minimal assessments for compatibility
        assessments = self._create_minimal_assessments(documents, refined_text_context)
        
        ontology_summary = self._create_ontology_summary(ontology) if include_ontology and ontology else ""
        
        return RefinedContext(
            original_context=structured_context,
            question=question,
            ontology_summary=ontology_summary,
            assessments=assessments,
            summary=f"created refined context: {context_length} chars, ~{estimated_tokens} tokens",
            enriched_context=refined_text_context
        )
    
    def _build_refined_prompt(
        self,
        question: str,
        documents: List[Dict[str, Any]],
        ontology: Optional[DynamicOntology],
        include_ontology: bool,
        aql_results_str: Optional[str]
    ) -> str:
        # build the compact refinement prompt that outputs text directly
        template = self.load_prompt("refinement_1pass_refined_exp4.txt")
        if not template:
            raise ValueError("refined prompt template not found")
        
        # format ontology
        ontology_text = self._format_ontology_for_prompt(ontology) if include_ontology and ontology else "no ontology provided"
        
        # extract documents from aql results for reference formatting
        documents = []
        if aql_results_str:
            from core.utils.aql_parser import parse_aql_results
            import json
            
            aql_data = parse_aql_results(aql_results_str)
            # format aql results in human-readable format for the llm
            aql_text = self._format_aql_for_prompt(aql_data)
            
            # parse the json string into a list of documents
            try:
                parsed_documents = json.loads(aql_data)
                if isinstance(parsed_documents, list):
                    documents = parsed_documents
                elif isinstance(parsed_documents, dict) and "error" in parsed_documents:
                    self.logger.warning(f"aql parsing error: {parsed_documents['error']}")
                else:
                    self.logger.warning(f"unexpected aql data format: {type(parsed_documents)}")
            except json.JSONDecodeError as e:
                self.logger.warning(f"failed to parse aql json: {e}")
            
            # log the parsed documents for debugging
            self.logger.debug(f"number of documents extracted: {len(documents)}")
            if len(documents) > 0:
                self.logger.debug(f"first document keys: {list(documents[0].keys())}")
            
            # log aql results reference information at info level
            self.logger.info(f"aql results contain {len(documents)} documents for reference extraction")
        else:
            aql_text = "no aql results provided"
            self.logger.info("no aql results provided for reference extraction")
        
        # format documents for references
        documents_text = self._format_documents_for_refined_prompt(documents)
        
        prompt = template.replace("{query}", question)
        prompt = prompt.replace("{ontology}", ontology_text)
        prompt = prompt.replace("{aql_results}", aql_text)
        prompt = prompt.replace("{documents}", documents_text)
        prompt = prompt.replace("{incomplete_references}", "")
        
        return prompt
    
    def _format_aql_for_prompt(self, aql_data: str) -> str:
        # format aql results in human-readable format for the llm
        import json
        
        try:
            documents = json.loads(aql_data)
            if not isinstance(documents, list):
                return aql_data
            
            formatted = []
            for i, doc in enumerate(documents, 1):
                title = doc.get('title', f'document {i}')
                abstract = doc.get('abstract', 'no abstract')
                uri = doc.get('uri', '')
                
                # compact format: title + abstract preview + uri
                abstract_preview = abstract[:200] + '...' if len(abstract) > 200 else abstract
                formatted.append(f"[{i}] {title}")
                formatted.append(f"   abstract: {abstract_preview}")
                if uri:
                    formatted.append(f"   uri: {uri}")
                formatted.append("")
            
            return "\n".join(formatted)
        except json.JSONDecodeError:
            return aql_data
    
    def _format_ontology_for_prompt(self, ontology: DynamicOntology) -> str:
        # format ontology in compact format for prompt
        if not ontology:
            return "no ontology"
        
        lines = []
        
        # combine all attributes and sort by centrality
        all_attributes = ontology.get_critical_attributes() + ontology.get_contextual_attributes()
        # remove duplicates based on attribute name
        unique_attributes = {}
        for attr in all_attributes:
            if attr.attribute not in unique_attributes:
                unique_attributes[attr.attribute] = attr
        
        # sort by centrality (descending)
        sorted_attributes = sorted(unique_attributes.values(), key=lambda x: x.centrality, reverse=True)
        
        lines.append("ontology attributes (sorted by relevance):")
        for attr in sorted_attributes:
            line = f"- {attr.attribute}: {attr.value}"
            if attr.description:
                line += f" ({attr.description})"
            line += f" (centrality: {attr.centrality:.2f})"
            lines.append(line)
        
        return "\n".join(lines)
    
    def _is_valid_reference(self, doc: Dict[str, Any]) -> bool:
        # check if a document is a valid reference with title and uri
        has_title = bool(doc.get("title_or_name") or doc.get("title"))
        has_uri = bool(doc.get("uri"))
        return has_title and has_uri
    
    def _format_documents_for_refined_prompt(self, documents: List[Dict[str, Any]]) -> str:
        # format documents for the refined prompt with openalex metadata
        if not documents:
            return "all document information is contained within the aql results section"
        
        formatted = []
        for i, doc in enumerate(documents, 1):
            if not self._is_valid_reference(doc):
                continue
            
            title = doc.get("title_or_name") or doc.get("title", f"document {i}")
            uri = doc.get("uri", "")
            
            # fetch metadata from openalex if uri is available
            metadata = None
            if uri and "openalex.org" in uri:
                metadata = OpenAlexClient.fetch_metadata(uri)
            
            if metadata:
                # use formatted reference with author/year
                metadata["position"] = i
                reference = format_reference_from_metadata(metadata)
                formatted.append(reference)
            else:
                # fallback to title + uri
                formatted.append(f"[{i}] {title}. {uri}." if uri else f"[{i}] {title}.")
        
        return "\n".join(formatted)
    
    def _get_refined_context_from_llm(self, prompt: str) -> str:
        # get the refined text context directly from llm with comprehensive logging
        try:
            self.logger.info(f"sending refinement prompt to llm (model: {getattr(self.llm, 'model', 'unknown')})")
            self.logger.debug(f"prompt length: {len(prompt)} characters")
            
            # save raw prompt to debug log file
            debug_logger = logging.getLogger('raw_prompts')
            debug_logger.debug(f"full refinement prompt sent to llm:\n{prompt}")
            
            response = self.llm.invoke(prompt)
            
            if response:
                response_length = len(response)
                self.logger.info(f"received refined context: {response_length} characters")
                self.logger.info(f"context preview: {response[:500]}...")
                return response.strip()
            else:
                self.logger.warning("empty response from llm")
                return "no refined context generated"
        except Exception as e:
            self.logger.error(f"failed to get refined context: {e}")
            self.logger.error("this may be due to api limits, network issues, or prompt formatting")
            return "error generating refined context"
    
    def _create_minimal_assessments(
        self,
        documents: List[Dict[str, Any]],
        refined_text: str
    ) -> List[DocumentAssessment]:
        # create minimal assessments for compatibility
        assessments = []
        for i, doc in enumerate(documents, 1):
            title = doc.get("title_or_name", f"document {i}")
            assessment = DocumentAssessment(
                title_or_name=title,
                relevance_score=0.7,
                include=True,
                geographic_scope=doc.get("geographic_scope", ""),
                temporal_scope=doc.get("temporal_scope", ""),
                what_is_relevant=f"document {i} from refined context",
                citation=title,
                full_reference=title,
                position=i,
                type="publication",
                scope="",
                caveats="",
                instruction="use for context"
            )
            assessments.append(assessment)
        return assessments
    
    def _assess_documents(
        self,
        question: str,
        documents: List[Dict[str, Any]],
        ontology: Optional[DynamicOntology],
        include_ontology: bool,
        aql_results_str: Optional[str] = None
    ) -> List[DocumentAssessment]:
        # this method is not used in the refined approach, but kept for compatibility
        return self._create_minimal_assessments(documents, "")
    
    def _create_ontology_summary(self, ontology: DynamicOntology) -> str:
        # create compact ontology summary
        if not ontology:
            return ""
        
        critical = len(ontology.get_critical_attributes())
        supporting = len(ontology.get_contextual_attributes())
        return f"{critical} critical, {supporting} supporting attributes"
