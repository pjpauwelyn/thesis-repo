# agents/base_refinement_agent.py

from abc import ABC, abstractmethod
from core.agents.base_agent import BaseAgent
from core.utils.data_models import DynamicOntology, DocumentAssessment, RefinedContext
from typing import List, Dict, Any, Optional
import re
import os

class BaseRefinementAgent(BaseAgent, ABC):
    def __init__(self, name: str, llm, prompt_dir: str = "prompts/refinement"):
        super().__init__(name, llm)
        self.prompt_dir = prompt_dir

    def load_prompt(self, filename: str) -> str:
        filepath = os.path.join(self.prompt_dir, filename)
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            self.logger.warning(f"Prompt not found: {filepath}")
            return ""

    def process_context(
        self,
        question: str,
        structured_context: str,
        ontology: Optional[DynamicOntology] = None,
        include_ontology: bool = True,
        aql_results_str: Optional[str] = None,
        context_filter: str = "full"
    ) -> RefinedContext:
        documents = self._parse_documents(structured_context, aql_results_str)
        self.logger.info(f"Parsed {len(documents)} documents")
        
        if not documents:
            return self._create_empty_context(question, ontology)
        
        # NEW: Apply ontology-guided document selection
        if include_ontology and ontology:
            selected_documents = self._select_documents_with_ontology(documents, ontology)
            if selected_documents != documents:
                self.logger.info(f"Ontology-guided selection: {len(documents)} → {len(selected_documents)} docs")
                documents = selected_documents
        
        assessments = self._assess_documents(question, documents, ontology, include_ontology, aql_results_str)
        enriched_context = self._build_enriched_context(assessments, context_filter, structured_context)
        
        included = [a for a in assessments if a.include]
        excluded = [a for a in assessments if not a.include]
        summary = f"Assessed {len(assessments)} docs: {len(included)} included, {len(excluded)} excluded"
        
        ontology_summary = ""
        if include_ontology and ontology:
            critical = ontology.get_critical_attributes()
            ontology_summary = f"Critical: {len(critical)} attrs, Supporting: {len(ontology.get_contextual_attributes())} attrs"
        
        return RefinedContext(
            original_context=structured_context,
            question=question,
            ontology_summary=ontology_summary,
            assessments=assessments,
            summary=summary,
            enriched_context=enriched_context
        )
        
    def process(self, input_data: Any) -> RefinedContext:
        """BaseAgent compatibility - delegates to process_context."""
        if isinstance(input_data, dict):
            return self.process_context(
                question=input_data.get("question", ""),
                structured_context=input_data.get("structured_context", ""),
                ontology=input_data.get("ontology"),
                include_ontology=input_data.get("include_ontology", True),
                aql_results_str=input_data.get("aql_results_str")
            )
        raise ValueError("Input must be a dictionary with required fields")


    def _parse_documents(self, context_string: str, aql_results_str: Optional[str] = None) -> List[Dict[str, Any]]:
        documents = []
        
        # Parse from structured_context first (this is more reliable)
        if "RELATED DOCUMENTS" in context_string:
            docs_section = context_string.split("RELATED DOCUMENTS")[1]
            if "RELATED TOPICS" in docs_section:
                docs_section = docs_section.split("RELATED TOPICS")[0]
            
            doc_blocks = docs_section.split("---")
            for i, block in enumerate(doc_blocks, 1):
                block = block.strip()
                if not block or block.startswith("#"):
                    continue
                
                title_match = re.search(r"[#\s]*Title[:\s]+([^\n]+)", block, re.MULTILINE)
                content_match = re.search(r"[#\s]*Content[:\s]+(.+?)(?:---|$)", block, re.MULTILINE | re.DOTALL)
                
                # Extract title from context, fallback to descriptive title
                if title_match:
                    title = title_match.group(1).strip()
                else:
                    # Try to extract meaningful phrase from content
                    if content_match:
                        first_sentence = content_match.group(1).strip().split('.')[0]
                        title = f"EO Study on {first_sentence[:50]}..." if first_sentence else f"Document {i}"
                    else:
                        title = f"Document {i}"
                
                content = content_match.group(1).strip() if content_match else block[:500]
                
                documents.append({
                    "id": f"doc{i}",
                    "title": title,
                    "title_or_name": title,
                    "position": i,
                    "type": "publication",
                    "content": content[:3000],
                    "aql_data": ""  # Placeholder for aql_results
                })
        
        # Add aql_results as clean parsed text to each document for LLM to use in assessment
        if aql_results_str and documents:
            from core.utils.aql_parser import parse_aql_results
            clean_aql_results = parse_aql_results(aql_results_str)
            
            if len(documents) == 1:
                documents[0]["aql_data"] = clean_aql_results
            else:
                documents[0]["aql_data"] = clean_aql_results
                documents[0]["aql_note"] = "Clean AQL results attached to this document for comprehensive assessment"
        
        self.logger.info(f"✅ Parsed {len(documents)} documents from structured context")
        if aql_results_str:
            self.logger.info("📊 AQL results attached to documents for LLM assessment")
        
        return documents
    
    def _select_documents_with_ontology(self, documents: List[Dict[str, Any]], ontology: Optional[DynamicOntology]) -> List[Dict[str, Any]]:
        """
        Use ontology to prioritize relevant documents.
        Falls back to original order if ontology is not available or documents are empty.
        """
        if not ontology or not documents or len(documents) <= 1:
            return documents
        
        try:
            # Extract key concepts from ontology
            key_concepts = [av.attribute.lower() for av in ontology.get_critical_attributes()]
            if not key_concepts:
                return documents
            
            # Score documents based on concept matches
            scored_docs = []
            for doc in documents:
                content = doc.get('content', '').lower()
                title = doc.get('title', '').lower()
                
                # Count concept matches in content and title
                score = sum(1 for concept in key_concepts 
                          if concept in content or concept in title)
                scored_docs.append((score, doc))
            
            # Sort by score (descending), then preserve original order for ties
            scored_docs.sort(reverse=True, key=lambda x: x[0])
            
            # Return documents in priority order
            return [doc for score, doc in scored_docs]
            
        except Exception as e:
            self.logger.warning(f"Ontology-guided document selection failed: {e}")
            return documents

    @abstractmethod
    def _assess_documents(
        self,
        question: str,
        documents: List[Dict[str, Any]],
        ontology: Optional[DynamicOntology],
        include_ontology: bool,
        aql_results_str: Optional[str]
    ) -> List[DocumentAssessment]:
        pass

    def _build_enriched_context(self, assessments: List[DocumentAssessment], context_filter: str = "full", structured_context: str = "") -> str:
        included = [a for a in assessments if a.include]
        if not included:
            return "No documents included after assessment."
        
        if context_filter == "scores_only":
            # Experiment 2: Only scores + original structured context
            return self._build_scores_only_context(included, structured_context)
        elif context_filter == "slim":
            # Experiment 1: Slim ontology - only essential fields
            return self._build_slim_context(included)
        else:
            # Full context - include everything
            return self._build_full_context(included)
    
    def _build_full_context(self, assessments: List[DocumentAssessment]) -> str:
        """Build complete enriched context with all fields"""
        lines = ["# Refined Context"]
        for idx, assessment in enumerate(assessments, 1):
            clean_title = self._clean_document_title(assessment.title_or_name)
            lines.append(f"\n## Document {idx}: {clean_title}")
            lines.append(f"**Relevance:** {assessment.relevance_score:.2f}")
            
            if assessment.geographic_scope:
                scope_line = f"**Geographic Scope:** {assessment.geographic_scope}"
                if assessment.geographic_match:
                    scope_line += f" ({assessment.geographic_match})"
                lines.append(scope_line)
            if assessment.temporal_scope:
                scope_line = f"**Temporal Scope:** {assessment.temporal_scope}"
                if assessment.temporal_match:
                    scope_line += f" ({assessment.temporal_match})"
                lines.append(scope_line)
            if assessment.what_is_relevant:
                lines.append(f"**Relevant Content:** {assessment.what_is_relevant}")
            if assessment.context_limitations:
                lines.append(f"**Limitations:** {assessment.context_limitations}")
            
            # 2‑pass enriched fields (will be empty for 1‑pass)
            if assessment.raw_metrics_text:
                lines.append(f"**Metrics:** {assessment.raw_metrics_text}")
            if assessment.spatial_context_text:
                lines.append(f"**Spatial Context:** {assessment.spatial_context_text}")
            if assessment.temporal_context_text:
                lines.append(f"**Temporal Context (detailed):** {assessment.temporal_context_text}")
            if assessment.supporting_details_text:
                lines.append(f"**Supporting Details:** {assessment.supporting_details_text}")
            
            if assessment.generation_instruction:
                lines.append(f"**Usage Guidance:** {assessment.generation_instruction}")
            
            # Citation fields - clean up placeholder text
            if assessment.citation:
                # Use cleaned document title
                clean_title = self._clean_document_title(assessment.title_or_name)
                clean_citation = assessment.citation.replace("[No author]", clean_title)
                clean_citation = clean_citation.replace("(n.d.)", "").replace("n.d.", "").strip()
                if clean_citation.endswith(","):
                    clean_citation = clean_citation[:-1]
                lines.append(f"**Citation:** {clean_citation}")
            if assessment.full_reference:
                # Clean up full reference placeholders
                clean_ref = assessment.full_reference
                clean_title = self._clean_document_title(assessment.title_or_name)
                if "[No author]" in clean_ref:
                    clean_ref = clean_ref.replace("[No author]", clean_title)
                if "n.d." in clean_ref:
                    clean_ref = clean_ref.replace("n.d.", "").replace("  ", " ").strip()
                lines.append(f"**Full Reference:** {clean_ref}")
        
        return "\n".join(lines)
    
    def _clean_document_title(self, title: str) -> str:
        """Clean up document title by removing placeholders"""
        if not title or title.strip() == "":
            return "Earth Observation Study"
        
        # Remove common placeholder patterns
        clean_title = (title.replace("Document Title", "")
                          .replace("Title:", "")
                          .replace(":", "")
                          .strip())
        
        if clean_title == "" or clean_title.lower() in ["unknown", "none", "n/a"]:
            return "Earth Observation Study"
        
        return clean_title

    def _build_slim_context(self, assessments: List[DocumentAssessment]) -> str:
        """Build slim context for experiment 1: only essential fields"""
        lines = ["# Refined Context (Slim)"]
        for idx, assessment in enumerate(assessments, 1):
            clean_title = self._clean_document_title(assessment.title_or_name)
            lines.append(f"\n## Document {idx}: {clean_title}")
            lines.append(f"**Relevance:** {assessment.relevance_score:.2f}")
            
            # Field 3: Geographic scope
            if assessment.geographic_scope:
                if assessment.geographic_match and assessment.geographic_match.lower() != 'none':
                    lines.append(
                        f"**Geographic Scope:** {assessment.geographic_scope} ({assessment.geographic_match})"
                    )
                else:
                    lines.append(f"**Geographic Scope:** {assessment.geographic_scope}")
            
            # Field 4: Temporal scope
            if assessment.temporal_scope:
                if assessment.temporal_match and assessment.temporal_match.lower() != 'none':
                    lines.append(
                        f"**Temporal Scope:** {assessment.temporal_scope} ({assessment.temporal_match})"
                    )
                else:
                    lines.append(f"**Temporal Scope:** {assessment.temporal_scope}")
            
            # Field 5: What is relevant (replacing context limitations)
            if assessment.what_is_relevant:
                lines.append(f"**Relevant Content:** {assessment.what_is_relevant}")
            
            # Field 10: Supporting details
            if assessment.supporting_details_text:
                lines.append(f"**Supporting Details:** {assessment.supporting_details_text}")
            
            # Field 11: Usage Guidance (use 'instruction' field from assessment)
            if assessment.instruction and assessment.instruction.strip():
                lines.append(f"**Usage Guidance:** {assessment.instruction}")
            
            # Citation fields
            if assessment.citation:
                lines.append(f"**Citation:** {assessment.citation}")
            if assessment.full_reference:
                lines.append(f"**Full Reference:** {assessment.full_reference}")
        
        return "\n".join(lines)
    
    def _build_scores_only_context(self, assessments: List[DocumentAssessment], structured_context: str) -> str:
        """Build scores-only context for experiment 2: original DARES structured context + relevance scores"""
        # Use only the original structured_context from DARES CSV, exactly as provided
        lines = [structured_context.strip()]
        lines.append("\n" + "="*60)
        lines.append("# Document Relevance Scores")
        
        for idx, assessment in enumerate(assessments, 1):
            clean_title = self._clean_document_title(assessment.title_or_name)
            lines.append(f"\n## Document {idx}: {clean_title}")
            lines.append(f"**Relevance Score:** {assessment.relevance_score:.2f}")
            
            # Include usage guidance for generation
            if assessment.generation_instruction:
                lines.append(f"**Usage Guidance:** {assessment.generation_instruction}")
            
            # Citation fields
            if assessment.citation:
                lines.append(f"**Citation:** {assessment.citation}")
            if assessment.full_reference:
                lines.append(f"**Full Reference:** {assessment.full_reference}")
        
        return "\n".join(lines)

    def _create_empty_context(self, question: str, ontology: Optional[DynamicOntology]) -> RefinedContext:
        ontology_summary = ""
        if ontology:
            ontology_summary = f"{len(ontology.attribute_value_pairs)} attributes extracted"
        
        return RefinedContext(
            original_context="",
            question=question,
            ontology_summary=ontology_summary,
            assessments=[],
            summary="No documents to refine",
            enriched_context="No documents available"
        )
