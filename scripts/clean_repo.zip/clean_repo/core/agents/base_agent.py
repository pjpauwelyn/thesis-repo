# agents/base_agent.py

from abc import ABC, abstractmethod
import time
from core.utils.helpers import setup_logging
from typing import Any

class BaseAgent(ABC):
    def __init__(self, name: str, llm):
        self.name = name
        self.llm = llm
        self.logger = setup_logging(self.name)

    @abstractmethod
    def process(self, input_data: Any) -> Any:
        pass

    def run(self, input_data: Any) -> Any:
        start_time = time.time()
        self.logger.info(f"Starting {self.name}...")
        try:
            output = self.process(input_data)
            elapsed = time.time() - start_time
            self.logger.info(f"Completed in {elapsed:.2f}s")
            return output
        except Exception as e:
            self.logger.error(f"Error: {e}", exc_info=True)
            raise
