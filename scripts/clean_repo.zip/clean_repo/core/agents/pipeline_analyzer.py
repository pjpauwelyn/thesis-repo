# pipeline_analyzer.py

import csv
import os
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

class PipelineAnalyzer:
    """Comprehensive logging and analysis for pipeline execution."""
    
    def __init__(self, log_dir: str = "analysis_logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger(__name__)
        
        # Create detailed analysis CSV
        self.analysis_file = self.log_dir / f"pipeline_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        # Define CSV headers
        self.fieldnames = [
            'timestamp', 'question_id', 'question', 'pipeline_type',
            'ontology_attributes_count', 'ontology_relationships_count',
            'aql_results_length', 'structured_context_length',
            'refinement_prompt_length', 'refined_context_length',
            'refined_context_tokens', 'context_within_target_range',
            'generation_input_length', 'final_answer_length',
            'processing_time', 'ontology_time', 'refinement_time', 'generation_time',
            'success_status', 'error_message', 'notes'
        ]
        
        # Initialize CSV file
        with open(self.analysis_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.fieldnames)
            writer.writeheader()
    
    def log_pipeline_execution(
        self,
        question_id: int,
        question: str,
        pipeline_type: str,
        ontology_attrs: int,
        ontology_rels: int,
        aql_length: int,
        structured_context_length: int,
        refinement_prompt_length: int,
        refined_context_length: int,
        refined_context_tokens: int,
        context_in_range: bool,
        generation_input_length: int,
        final_answer_length: int,
        processing_time: float,
        ontology_time: float,
        refinement_time: float,
        generation_time: float,
        success: bool,
        error_msg: Optional[str] = None,
        notes: str = ""
    ) -> None:
        """Log comprehensive pipeline execution data."""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'question_id': question_id,
            'question': question[:100] + '...' if len(question) > 100 else question,
            'pipeline_type': pipeline_type,
            'ontology_attributes_count': ontology_attrs,
            'ontology_relationships_count': ontology_rels,
            'aql_results_length': aql_length,
            'structured_context_length': structured_context_length,
            'refinement_prompt_length': refinement_prompt_length,
            'refined_context_length': refined_context_length,
            'refined_context_tokens': refined_context_tokens,
            'context_within_target_range': context_in_range,
            'generation_input_length': generation_input_length,
            'final_answer_length': final_answer_length,
            'processing_time': f"{processing_time:.2f}",
            'ontology_time': f"{ontology_time:.2f}",
            'refinement_time': f"{refinement_time:.2f}",
            'generation_time': f"{generation_time:.2f}",
            'success_status': 'success' if success else 'failed',
            'error_message': error_msg[:200] if error_msg else '',
            'notes': notes[:100]
        }
        
        # Write to CSV
        with open(self.analysis_file, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.fieldnames)
            writer.writerow(log_entry)
        
        self.logger.info(f"📊 Analysis logged to {self.analysis_file}")
    
    def log_detailed_context_analysis(
        self,
        question_id: int,
        original_context: str,
        refined_context: str,
        ontology_summary: str
    ) -> None:
        """Log detailed context analysis for manual review."""
        
        # Create separate detailed log file for this question
        detail_file = self.log_dir / f"question_{question_id}_detailed_analysis.txt"
        
        with open(detail_file, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("DETAILED PIPELINE ANALYSIS\n")
            f.write("="*80 + "\n\n")
            
            f.write("1. ORIGINAL STRUCTURED CONTEXT\n")
            f.write("-" * 40 + "\n")
            f.write(f"Length: {len(original_context)} characters\n")
            f.write(f"Preview: {original_context[:200]}...\n\n")
            
            f.write("2. ONTOLOGY SUMMARY\n")
            f.write("-" * 40 + "\n")
            f.write(f"{ontology_summary}\n\n")
            
            f.write("3. REFINED CONTEXT (Generation Agent Input)\n")
            f.write("-" * 40 + "\n")
            f.write(f"Length: {len(refined_context)} characters\n")
            f.write(f"Estimated tokens: ~{len(refined_context) // 4}\n")
            f.write(f"\nFull context:\n{refined_context}\n\n")
            
            # Analyze context structure
            f.write("4. CONTEXT STRUCTURE ANALYSIS\n")
            f.write("-" * 40 + "\n")
            
            if "[ONTOLOGY SUMMARY]" in refined_context:
                f.write("✅ Ontology summary section found\n")
            else:
                f.write("❌ Ontology summary section missing\n")
                
            if "[TOPICS AND INFORMATION]" in refined_context:
                f.write("✅ Topics and information section found\n")
            else:
                f.write("❌ Topics and information section missing\n")
                
            if "[DOCUMENTS]" in refined_context:
                f.write("✅ Documents section found\n")
            else:
                f.write("❌ Documents section missing\n")
                
            if "[CAVEATS & GAPS]" in refined_context:
                f.write("✅ Caveats and gaps section found\n")
            else:
                f.write("❌ Caveats and gaps section missing\n")
        
        self.logger.info(f"📄 Detailed analysis saved to {detail_file}")
    
    def get_analysis_file_path(self) -> str:
        """Get the path to the analysis CSV file."""
        return str(self.analysis_file)
    
    def get_log_directory(self) -> str:
        """Get the log directory path."""
        return str(self.log_dir)
