# agents/generation_agent.py

from core.agents.base_agent import BaseAgent
from core.utils.data_models import DynamicOntology
from typing import Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import os

@dataclass
class Answer:
    answer: str
    references: List[str] = field(default_factory=list)
    formatted_references: List[str] = field(default_factory=list)
    timestamp: str = ""
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()

class GenerationAgent(BaseAgent):
    def __init__(self, llm, prompt_dir: str = "prompts/generation"):
        super().__init__("GenerationAgent", llm)
        self.prompt_dir = prompt_dir
        self.zero_shot_template = self._load_template("zero_shot.txt")
        self.refinement_template = self._load_template("generation_prompt_exp4.txt")
    
    def _load_template(self, filename: str) -> str:
        try:
            filepath = os.path.join(self.prompt_dir, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            self.logger.warning(f"Template not found: {filepath}")
            return ""
    
    def process(self, input_data):
        pass
    
    def generate(
        self,
        question: str,
        text_context: str,
        ontology: Optional[DynamicOntology] = None
    ) -> Answer:
        """generation: zero-shot with context and ontology."""
        self.logger.info(f"Generating answer for: {question[:80]}...")
        
        # Step 1: Generate zero-shot answer (question only)
        zero_shot_prompt = self.zero_shot_template.replace("{question}", question)
        self.logger.info("📝 Generating zero-shot answer...")
        draft_answer = self._generate_with_llm(zero_shot_prompt, prompt_type="zero-shot")
        
        # Step 2: Refine answer with context and ontology
        refinement_prompt = self._create_refinement_prompt(question, draft_answer, text_context, ontology)
        self.logger.info("📝 Generating refined answer with context...")
        final_answer = self._generate_with_llm(refinement_prompt, prompt_type="refinement")
        
        # Extract references from the final answer
        references = self._extract_references(final_answer)
        formatted_references = self._extract_formatted_references(final_answer)
        
        # If no references are found, try to extract them from the context
        if not formatted_references and text_context:
            self.logger.debug("Extracting references from context...")
            formatted_references = self._extract_references_from_context(text_context)
            self.logger.debug(f"Extracted {len(formatted_references)} references from context.")
        
        self.logger.info("Generation completed")
        return Answer(answer=final_answer, references=references, formatted_references=formatted_references)
    
    def _create_refinement_prompt(self, question: str, draft_answer: str, text_context: str, ontology: Optional[DynamicOntology] = None) -> str:
        prompt = self.refinement_template
        
        # Replace placeholders
        prompt = prompt.replace("{question}", question)
        prompt = prompt.replace("{draft_answer}", draft_answer)
        
        if text_context and text_context.strip():
            prompt = prompt.replace("{context}", text_context)
        else:
            prompt = prompt.replace("{context}", "No additional context available.")
        
        if ontology and ontology.attribute_value_pairs:
            ontology_lines = []
            for av_pair in ontology.attribute_value_pairs:
                ontology_lines.append(f"- {av_pair.attribute}: {av_pair.value} ({av_pair.description})")
            
            if ontology.logical_relationships:
                ontology_lines.append("\nRelationships:")
                for rel in ontology.logical_relationships:
                    ontology_lines.append(f"  - {rel.source_attribute} {rel.relationship_type} {rel.target_attribute}")
            
            ontology_section = "\n".join(ontology_lines)
            prompt = prompt.replace("{ontology}", ontology_section)
        else:
            prompt = prompt.replace("{ontology}", "No ontology constraints.")
        
        return prompt
    
    def _generate_with_llm(self, prompt: str, prompt_type: str = "generation") -> str:
        """Generate answer using the LLM."""
        try:
            prompt_length = len(prompt)
            estimated_tokens = prompt_length // 4
            log_prefix = "zero-shot" if prompt_type == "zero-shot" else "refinement" if prompt_type == "refinement" else "generation"
            self.logger.info(f"📊 {log_prefix.capitalize()} prompt statistics:")
            self.logger.info(f"   - Prompt length: {prompt_length} characters")
            self.logger.info(f"   - Estimated tokens: ~{estimated_tokens} tokens")
            
            # Save raw prompt to debug log file instead of terminal
            import logging
            debug_logger = logging.getLogger('raw_prompts')
            debug_logger.debug(f"📝 {log_prefix.capitalize()} raw prompt logged to debug file: {prompt[:200]}...")
            debug_logger.debug(f"Full {log_prefix} prompt:\n{prompt}")
            
            # Inform user that raw prompt is logged to file (only for refinement prompts to avoid spam)
            if prompt_type == "refinement":
                self.logger.info(f"📝 Raw {log_prefix} prompt logged to 'raw_prompts_debug.log'")
            
            response = self.llm.invoke(prompt, force_json=False)
            response_length = len(response)
            response_tokens = response_length // 4
            self.logger.info(f"📊 Generation response statistics:")
            self.logger.info(f"   - Response length: {response_length} characters")
            self.logger.info(f"   - Estimated tokens: ~{response_tokens} tokens")
            return response.strip()
        except Exception as e:
            self.logger.error(f"LLM generation failed: {e}")
            return "Error: Could not generate answer."

    def _extract_references(self, answer: str) -> List[str]:
        """Extract and clean references from the generated answer."""
        references = []
        
        # Look for References section
        if "References" not in answer and "REFERENCES" not in answer:
            return references
        
        # Find references section and clean placeholders
        lines = answer.split('\n')
        in_references = False
        
        for line in lines:
            line = line.strip()
            if ("References" in line or "REFERENCES" in line) and not line.startswith("["):
                in_references = True
                continue
            elif in_references and line:
                # Clean reference line and remove placeholders
                ref = line.strip("-•* []")
                if ref and "No author" not in ref and "No source" not in ref and "[EVIDENCE]" not in ref:
                    # Remove multiple spaces and clean up
                    ref = ' '.join(ref.split())
                    references.append(ref)
            elif in_references and not line:
                break
        
        return references
    
    def _extract_formatted_references(self, answer: str) -> List[str]:
        """Extract formatted references (e.g., [1] Document Title. (Year). Source.) from the generated answer."""
        formatted_references = []
        
        # Look for References section
        if "References" not in answer and "REFERENCES" not in answer:
            return formatted_references
        
        # Find references section and extract formatted references
        lines = answer.split('\n')
        in_references = False
        
        for line in lines:
            line = line.strip()
            if ("References" in line or "REFERENCES" in line) and not line.startswith("["):
                in_references = True
                continue
            elif in_references and line:
                # Extract formatted reference (e.g., [1] Document Title. (Year). Source.)
                if line.startswith('[') and ']' in line and "[EVIDENCE]" not in line:
                    formatted_references.append(line.strip())
            elif in_references and not line:
                break
        
        return formatted_references
    
    def _extract_references_from_context(self, context: str) -> List[str]:
        """Extract references from the context (e.g., [VALIDATED REFERENCES] section)."""
        references = []
        
        # Look for VALIDATED REFERENCES section
        if "[VALIDATED REFERENCES]" not in context:
            return references
        
        # Extract references from the context
        lines = context.split('\n')
        in_references = False
        
        for line in lines:
            line = line.strip()
            if line.startswith("[VALIDATED REFERENCES]"):
                in_references = True
                continue
            elif in_references and line:
                # Extract reference (e.g., [1] Author et al. (Year). *Title*. URI.)
                if line.startswith('[') and ']' in line:
                    references.append(line.strip())
            elif in_references and not line:
                break
        
        return references
    

