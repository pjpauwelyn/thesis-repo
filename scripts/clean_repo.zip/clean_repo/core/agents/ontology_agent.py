# agents/ontology_agent.py

from core.agents.base_agent import BaseAgent
from core.utils.data_models import AttributeValuePair, LogicalRelationship, DynamicOntology
from typing import List
import os

class OntologyConstructionAgent(BaseAgent):
    def __init__(self, llm, prompt_dir: str = "prompts/ontology"):
        super().__init__("OntologyConstructionAgent", llm)
        self.prompt_dir = prompt_dir
    
    def load_prompt(self, filename: str) -> str:
        filepath = os.path.join(self.prompt_dir, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    
    def process(self, question: str, include_relationships: bool = True) -> DynamicOntology:
        """Simple ontology construction with optional relationships."""
        
        # Extract attribute-value pairs
        av_pairs = self._extract_attribute_value_pairs(question)
        self.logger.info(f"Extracted {len(av_pairs)} attribute-value pairs")
        
        # Define logical relationships (optional)
        relationships = []
        if include_relationships:
            relationships = self._define_logical_relationships(av_pairs, question)
            self.logger.info(f"Defined {len(relationships)} logical relationships")
        else:
            self.logger.info("Skipping logical relationships (optional feature disabled)")
        
        return DynamicOntology(
            attribute_value_pairs=av_pairs,
            logical_relationships=relationships,
            source_query=question,
            should_use_ontology=True,
            include_relationships=include_relationships
        )
    
    def _extract_attribute_value_pairs(self, question: str) -> List[AttributeValuePair]:
        """Extract attribute-value pairs using LLM."""
        template = self.load_prompt("extract_attributes_slim.txt")
        prompt = template.replace("{question}", question)
        
        try:
            response = self.llm.invoke(prompt, force_json=True)
            
            # Parse the response - expect the exact format specified in the prompt
            if isinstance(response, dict) and 'pairs' in response:
                return [
                    AttributeValuePair(
                        attribute=attr.get('attribute', ''), 
                        value=attr.get('value', ''), 
                        description=attr.get('description', ''),
                        centrality=attr.get('centrality', 0.5)  # Default to 0.5 if missing
                    )
                    for attr in response['pairs']
                ]
            else:
                self.logger.error(f"LLM did not return expected format. Expected dict with 'pairs' key, got: {type(response)}")
                return []
        except Exception as e:
            self.logger.error(f"Failed to extract attributes: {e}")
            return []
        
        return []
    
    def _define_logical_relationships(self, av_pairs: List[AttributeValuePair], question: str) -> List[LogicalRelationship]:
        """Define logical relationships using LLM."""
        if not av_pairs:
            return []
            
        # Create relationships prompt
        attributes_text = "\n".join([f"- {av.attribute}: {av.value}" for av in av_pairs])
        template = self.load_prompt("extract_relationships.txt")
        prompt = template.replace("{question}", question).replace("{attributes}", attributes_text)
        
        try:
            response = self.llm.invoke(prompt, force_json=True)
            
            if isinstance(response, dict) and 'relationships' in response:
                return [
                    LogicalRelationship(
                        source_attribute=rel.get('source_attribute', ''),
                        source_value=rel.get('source_value', ''),
                        target_attribute=rel.get('target_attribute', ''),
                        target_value=rel.get('target_value', ''),
                        relationship_type=rel.get('relationship_type', 'relates_to'),
                        logical_constraint=rel.get('logical_constraint', '')
                    )
                    for rel in response['relationships']
                ]
            else:
                self.logger.error(f"LLM did not return expected format. Expected dict with 'relationships' key, got: {type(response)}")
                return []
        except Exception as e:
            self.logger.error(f"Failed to define relationships: {e}")
            return []
        
        return []