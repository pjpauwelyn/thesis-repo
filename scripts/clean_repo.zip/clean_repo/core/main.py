# orchestrator.py
# (AI generated)

import os
import sys
import csv
import json
import logging
import argparse
import traceback
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field, asdict
from collections import deque
import statistics
csv.field_size_limit(int(1e8))

# Custom logging filter to deduplicate consecutive identical log messages
class DuplicateFilter(logging.Filter):
    def filter(self, record):
        current = (record.name, record.levelno, record.getMessage())
        if current == getattr(self, "_last", None):
            return False
        self._last = current
        return True

# Configure logging with separate handlers for console and file
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)  # Root logger captures everything

# Console handler - shows only INFO and above by default
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_formatter = logging.Formatter("%(message)s")  # Clean format for users
console_handler.setFormatter(console_formatter)
console_handler.addFilter(DuplicateFilter())  # Add deduplication filter

# File handler - captures DEBUG and above for detailed logging
file_handler = logging.FileHandler("pipeline_debug.log", mode='w')
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(file_formatter)
file_handler.addFilter(DuplicateFilter())  # Add deduplication filter to file handler as well

# Add handlers to logger
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# Suppress noisy third-party logs
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Raw prompts logger - saves full prompts to separate file for debugging
raw_prompts_logger = logging.getLogger('raw_prompts')
raw_prompts_handler = logging.FileHandler("raw_prompts_debug.log", mode='w')
raw_prompts_handler.setLevel(logging.DEBUG)
raw_prompts_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
raw_prompts_handler.setFormatter(raw_prompts_formatter)
raw_prompts_logger.addHandler(raw_prompts_handler)
raw_prompts_logger.setLevel(logging.DEBUG)
raw_prompts_logger.propagate = False  # Prevent duplicate logging to root logger

from core.utils.helpers import get_llm_model
from core.agents.ontology_agent import OntologyConstructionAgent
from core.agents.refinement_agent_1pass import RefinementAgent as RefinementAgent1Pass
from core.agents.refinement_agent_1pass_refined import RefinementAgent1PassRefined
from core.agents.pipeline_analyzer import PipelineAnalyzer
from core.agents.generation_agent import GenerationAgent

@dataclass
class PipelineResult:
    index: int
    question: str
    answer: str = ""
    references: List[str] = field(default_factory=list)
    ontology: Optional[str] = None
    refined_context_summary: Optional[str] = None
    final_text_context: Optional[str] = None
    time_elapsed: float = 0.0
    status: str = "success"
    error_message: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class PipelineStats:
    total: int = 0
    successful: int = 0
    failed: int = 0
    avg_time: float = 0.0

    def update(self, results: List[PipelineResult]):
        self.total = len(results)
        self.successful = sum(1 for r in results if r.status == "success")
        self.failed = sum(1 for r in results if r.status == "error")
        
        successful_results = [r for r in results if r.status == "success"]
        if successful_results:
            self.avg_time = sum(r.time_elapsed for r in successful_results) / len(successful_results)

class PerformanceMonitor:
    """Real-time performance monitoring and alerting system."""
    
    def __init__(self, window_size: int = 10):
        self.window_size = window_size
        self.processing_times = deque(maxlen=window_size)
        self.success_rates = deque(maxlen=window_size)
        self.error_types = deque(maxlen=window_size)
        self.alert_thresholds = {
            'slow_processing': 30.0,  # seconds
            'low_success_rate': 0.8,  # 80% success rate
            'high_error_rate': 0.2    # 20% error rate
        }
        self.alerts_issued = set()
    
    def record_processing_time(self, time_elapsed: float):
        """Record processing time for a single question."""
        self.processing_times.append(time_elapsed)
        self._check_performance_alerts()
    
    def record_result(self, success: bool, error_type: str = None):
        """Record the result of processing a question."""
        self.success_rates.append(1 if success else 0)
        if error_type:
            self.error_types.append(error_type)
        self._check_performance_alerts()
    
    def _check_performance_alerts(self):
        """Check for performance issues and issue alerts if needed."""
        if len(self.processing_times) < self.window_size // 2:
            return  # Not enough data yet
        
        # Check for slow processing
        avg_time = statistics.mean(self.processing_times)
        if avg_time > self.alert_thresholds['slow_processing']:
            if 'slow_processing' not in self.alerts_issued:
                logger.warning(f"🚨 PERFORMANCE ALERT: Slow processing detected (avg: {avg_time:.1f}s > {self.alert_thresholds['slow_processing']}s)")
                self.alerts_issued.add('slow_processing')
        
        # Check for low success rate
        if self.success_rates:
            success_rate = statistics.mean(self.success_rates)
            if success_rate < self.alert_thresholds['low_success_rate']:
                if 'low_success_rate' not in self.alerts_issued:
                    logger.warning(f"🚨 PERFORMANCE ALERT: Low success rate detected ({success_rate:.1%} < {self.alert_thresholds['low_success_rate']:.0%})")
                    self.alerts_issued.add('low_success_rate')
        
        # Check for high error rate
        if self.error_types and len(self.error_types) >= 3:
            error_rate = sum(1 for et in self.error_types if et) / len(self.error_types)
            if error_rate > self.alert_thresholds['high_error_rate']:
                if 'high_error_rate' not in self.alerts_issued:
                    # Count error types
                    error_counts = {}
                    for et in self.error_types:
                        if et:
                            error_counts[et] = error_counts.get(et, 0) + 1
                    
                    error_summary = ", ".join(f"{k}: {v}" for k, v in error_counts.items())
                    logger.warning(f"🚨 PERFORMANCE ALERT: High error rate detected ({error_rate:.1%} > {self.alert_thresholds['high_error_rate']:.0%}): {error_summary}")
                    self.alerts_issued.add('high_error_rate')
    
    def get_performance_summary(self) -> dict:
        """Get current performance summary."""
        summary = {
            'avg_processing_time': round(statistics.mean(self.processing_times), 2) if self.processing_times else 0,
            'success_rate': round(statistics.mean(self.success_rates), 3) if self.success_rates else 0,
            'total_processed': len(self.processing_times),
            'active_alerts': list(self.alerts_issued)
        }
        
        if self.error_types and len(self.error_types) > 0:
            error_rate = sum(1 for et in self.error_types if et) / len(self.error_types)
            summary['error_rate'] = round(error_rate, 3)
        
        return summary
    
    def clear_alert(self, alert_type: str):
        """Clear a specific alert."""
        if alert_type in self.alerts_issued:
            self.alerts_issued.remove(alert_type)
            logger.info(f"✅ Performance alert cleared: {alert_type}")

class PipelineOrchestrator:
    PIPELINE_TYPES = {
        "1_pass_with_ontology": "1-Pass with Ontology",
        "1_pass_without_ontology": "1-Pass without Ontology",
        "1_pass_with_ontology_refined": "1-Pass with Ontology Refined",
    }

    def __init__(self, pipeline_type: str, model_name: str = "mistral-small-latest", prompt_dir: str = "prompts", use_dlr_compatible: bool = False, use_hybrid_models: bool = False, context_filter: str = "full", include_ontology_relationships: bool = False, experiment_type: str = "default", overwrite: bool = False, refinement_temperature: float = 0.1, generation_temperature: float = 0.2, auto_evaluate: bool = False, evaluation_model: str = "gpt-4.1-mini"):
        if pipeline_type not in self.PIPELINE_TYPES:
            raise ValueError(f"Invalid pipeline type: {pipeline_type}")
        
        self.pipeline_type = pipeline_type
        self.prompt_dir = prompt_dir
        self.use_dlr_compatible = use_dlr_compatible
        self.context_filter = context_filter
        self.include_ontology_relationships = include_ontology_relationships
        self.auto_evaluate = auto_evaluate
        self.evaluator = None  # Initialize to None by default
        
        # Initialize DLR evaluator if auto-evaluation is enabled
        if self.auto_evaluate:
            try:
                # Import here to avoid circular dependencies
                import sys
                sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'evaluation'))
                from dlr_evaluation import DLREvaluator
                self.evaluator = DLREvaluator(model_name=evaluation_model)
                logger.info(f"🔍 Auto-evaluation enabled with {evaluation_model}")
            except Exception as e:
                logger.warning(f"Could not initialize DLR evaluator: {e}")
                logger.warning("Auto-evaluation will be disabled")
                self.auto_evaluate = False
                self.evaluator = None
        
        # Model configuration based on hybrid_models flag
        if use_hybrid_models:
            # Hybrid approach: devstral for structured tasks, specified model for generation
            ontology_refinement_model = "mistral-small-latest"
            generation_model = model_name  # Use the specified model for generation
            logger.info(f"Using mistral-small-latest for all tasks")
        else:
            # Single model approach: devstral for ontology/refinement, specified model for generation
            ontology_refinement_model = "mistral-small-latest"
            generation_model = model_name  # Use the specified model for generation
            logger.info(f"Using mistral-small-latest for all tasks")
        
        # Create separate LLM instances for different tasks with custom temperatures
        self.ontology_refinement_llm = get_llm_model(model=ontology_refinement_model, temperature=refinement_temperature)
        self.generation_llm = get_llm_model(model=generation_model, temperature=generation_temperature)
        
        self.ontology_agent = OntologyConstructionAgent(self.ontology_refinement_llm, prompt_dir=f"{prompt_dir}/ontology")

        self.refinement_agent_1pass: Optional[RefinementAgent1Pass] = None
        self.refinement_agent_1pass_refined: Optional[RefinementAgent1PassRefined] = None
        self.pipeline_analyzer = PipelineAnalyzer()

        if "1_pass_with_ontology_refined" in pipeline_type:
            # Use mistral-small-latest for refined pipeline (mistral-medium-latest may not be available)
            from core.agents.refinement_agent_1pass_refined import RefinementAgent1PassRefined
            refined_llm = get_llm_model(model="mistral-small-latest", temperature=refinement_temperature)
            self.refinement_agent_1pass_refined = RefinementAgent1PassRefined(refined_llm, prompt_dir=f"{prompt_dir}/refinement")
        elif "1_pass" in pipeline_type:
            self.refinement_agent_1pass = RefinementAgent1Pass(self.ontology_refinement_llm, prompt_dir=f"{prompt_dir}/refinement")

        # Always use simplified DLR-inspired generation agent
        self.generation_agent = GenerationAgent(self.generation_llm)
        logger.info(f"Orchestrator initialized: {self.PIPELINE_TYPES[pipeline_type]} (simplified DLR-inspired approach)")

        # Initialize grounding enforcer for quality assurance
        # Use DLR-style minimal grounding: 2 references max, less aggressive
        # Grounding enforcer removed - using simple generation approach

        # Store experiment type and overwrite flag
        # Auto-set experiment type for refined context pipelines if not explicitly provided
        if "1_pass_with_ontology_refined" in pipeline_type and experiment_type == "default":
            self.experiment_type = "refined_context"
        else:
            self.experiment_type = experiment_type
        self.overwrite = overwrite

    def _get_tracking_key(self, question_id):
        """Generate consistent tracking key for anti-re-evaluation"""
        # Use the actual question ID from the input CSV for consistent tracking
        if self.experiment_type == "default":
            return f"{question_id}_{self.pipeline_type}"
        return f"{question_id}_{self.pipeline_type}_{self.experiment_type}"

    def _should_process_question(self, question_id, existing_results):
        """Determine if question should be processed based on tracking"""
        if self.overwrite:
            return True
        
        key = self._get_tracking_key(question_id)
        
        # If not in existing results, process it
        if key not in existing_results:
            return True
        
        # If it's a failed answer, automatically re-evaluate it
        # (existing_results stores status: True=success, False=failed)
        if existing_results[key] is False:  # Failed answer
            return True
        
        # Already successfully processed, skip it
        return False

    def run(
        self,
        input_csv: str,
        num_questions: Optional[int] = None,
        output_dir: Optional[str] = None,
        output_csv: Optional[str] = None,
        save_to_csv: bool = False,
        verbose: bool = True,
        indices: Optional[List[int]] = None,
    ) -> Tuple[List[PipelineResult], str, PipelineStats]:
        try:
            with open(input_csv, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                data = list(reader)
        except FileNotFoundError:
            logger.error(f"CSV file not found: {input_csv}")
            return [], "", PipelineStats()
        
        if num_questions:
            data = data[:num_questions]
        # Initialize idx_to_original mapping (will be empty if no indices specified)
        idx_to_original = {}
        
        if indices:
            data = [row for i, row in enumerate(data) if i in indices]
            # Create mapping of filtered index to original index
            idx_to_original = {filtered_idx: original_idx for filtered_idx, original_idx in enumerate(indices)}
        
        # Extract original question IDs from input CSV and track original indices
        original_question_ids = []
        original_indices = list(range(len(data)))  # Track original indices before any slicing
        
        for row in data:
            # Try to get question_id from input CSV, fall back to index-based ID
            question_id = row.get('question_id', '')
            if question_id:
                try:
                    original_question_ids.append(int(question_id))
                except ValueError:
                    original_question_ids.append(None)
            else:
                original_question_ids.append(None)
        
        # After filtering, we need to update original_question_ids to match filtered data
        # Create a mapping from original index to question ID
        original_id_map = {i: qid for i, qid in enumerate(original_question_ids)}
        
        if output_dir is None and output_csv is None:
            # Use the new results directory convention
            results_base_dir = Path("results_to_be_processed")
            results_base_dir.mkdir(parents=True, exist_ok=True)
            
            # Create consistent CSV filename based on pipeline type
            # For refined context pipeline, always use refined-context_results.csv
            pipeline_name = self.pipeline_type.replace("_", "-")  # Replace underscores for cleaner filenames
            
            if "1_pass_with_ontology_refined" in self.pipeline_type:
                # Always use refined-context_results.csv for refined context pipeline
                filename = f"refined-context_results.csv"
            else:
                # For other pipelines, use pipeline_name_results.csv
                filename = f"{pipeline_name}_results.csv"
            
            output_dir = results_base_dir / filename
            output_path = output_dir  # Set output_path here for anti-re-evaluation
        elif output_csv is not None:
            # Use custom CSV filename
            output_path = Path(output_csv)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_dir = str(output_path)
        else:
            # If custom output dir specified, use it but ensure parent exists
            output_path = Path(output_dir)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            # If the output_dir is a CSV file, use it directly
            if output_path.suffix == '.csv':
                # Ensure the directory exists
                output_path.parent.mkdir(parents=True, exist_ok=True)
            else:
                # For directory output, create the directory
                output_path.mkdir(parents=True, exist_ok=True)
        
        # ANTI-RE-EVALUATION: Check existing results to avoid duplicate work
        existing_results = {}
        if output_path.suffix == '.csv' and output_path.exists():
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        question_id = row.get('question_id', '')
                        pipeline = row.get('pipeline', '')
                        experiment_type = row.get('experiment_type', 'default')
                        
                        # Check if this is a failed answer (starts with "Error:" or has explicit error status)
                        answer = row.get('answer', '').strip()
                        has_error = answer.startswith('Error:') or answer.startswith('error:')
                        
                        # Handle both old and new tracking key formats
                        # In new format, status is determined by whether the row exists and has an answer
                        if row.get('status'):
                            status = row.get('status', 'success').lower() == 'success'
                        else:
                            # If no explicit status, treat as success unless answer contains error
                            status = not has_error
                        
                        if experiment_type == 'default':
                            existing_results[f"{question_id}_{pipeline}"] = status
                        else:
                            existing_results[f"{question_id}_{pipeline}_{experiment_type}"] = status
            except Exception as e:
                logger.warning(f"Could not read existing results: {e}")
        
        # Filter out questions that have already been processed for this pipeline
        filtered_data = []
        skipped_count = 0
        for idx, row in enumerate(data):
            # Track original question index for CSV updates
            original_idx = original_indices[idx] if idx < len(original_indices) else idx
            # Use original question ID from input CSV if available, otherwise use 1-based index based on original position
            question_id = row.get('question_id')
            if not question_id:  # If question_id is empty or None, use the index
                question_id = str(original_idx + 1)
            
            if self._should_process_question(question_id, existing_results):
                filtered_data.append(row)
            else:
                if verbose:
                    logger.info(f"⏭️  Skipping question {question_id} - already processed")
                skipped_count += 1
        
        if verbose and skipped_count > 0:
            logger.info(f"📊 Anti-re-evaluation: Skipped {skipped_count} already-processed questions")
        
        # Use filtered data for processing
        data = filtered_data
        
        if verbose:
            self._print_header(data)
        
        results = []
        # Calculate the next available question ID based on existing results
        max_existing_question_id = 0
        if existing_results:
            # Extract question IDs from existing results
            existing_question_ids = []
            for key in existing_results.keys():
                # Parse question_id from tracking key format: "question_id_pipeline_experiment"
                parts = key.split('_')
                if len(parts) >= 2:
                    try:
                        qid = int(parts[0])
                        existing_question_ids.append(qid)
                    except ValueError:
                        pass
            if existing_question_ids:
                max_existing_question_id = max(existing_question_ids)
        
        for idx, row in enumerate(data):
            # Get original question ID from the mapping (handles filtered data correctly)
            original_question_id = original_id_map.get(idx, None)
            
            # If no original question ID (new questions), calculate sequential ID
            if original_question_id is None:
                # Check if this appears to be a fresh batch (most questions have no IDs)
                # If so, start numbering from 1. Otherwise, continue from max existing ID.
                none_count = sum(1 for qid in original_question_ids if qid is None)
                total_questions = len(original_question_ids)
                
                # If 80% or more questions have no IDs, treat as fresh batch
                if total_questions > 0 and none_count / total_questions >= 0.8:
                    original_question_id = idx + 1  # Start from 1 for fresh batch
                else:
                    original_question_id = max_existing_question_id + idx + 1  # Continue existing sequence
            
            result = self._process_question(idx, row, verbose=verbose, original_question_id=original_question_id)
            
            # Auto-evaluate if enabled and generation was successful
            if self.auto_evaluate and result.status == "success":
                evaluation = self._evaluate_result(result)
                if evaluation:
                    result.evaluation = evaluation
                    logger.info(f"📊 Evaluation added to result for question {original_question_id}")
            
            results.append(result)
        
        stats = PipelineStats()
        stats.update(results)
        
        self._save_results(results, stats, output_path, verbose=verbose)
        
        if save_to_csv:
            self._update_csv_with_results(str(output_path), results)
        
        if verbose:
            self._print_summary(stats, output_path)
        
        return results, str(output_path), stats

    def _process_question(self, idx: int, row: Dict, verbose: bool = True, original_question_id: int = None):
        question = row.get("question", "")
        if verbose:
            print(f"\n[{idx+1}] {question[:70]}...")
        
        result = PipelineResult(index=idx, question=question)
        # Use the original question ID that was calculated in the main loop
        result.original_question_id = original_question_id
        result.original_index = idx  # Track original question index for CSV updates
        
        # Get AQL results from row for tracking
        aql_results = row.get("aql_results", "")
        
        # Track clean AQL results for CSV output
        if aql_results:
            from core.utils.aql_parser import parse_aql_results
            result.clean_aql_used = parse_aql_results(aql_results)
        else:
            result.clean_aql_used = ''
        start_time = time.time()
        ontology_start = time.time()
        
        # Initialize analysis variables
        ontology_attrs = 0
        ontology_rels = 0
        refinement_prompt_length = 0
        refined_context_length = 0
        refined_context_tokens = 0
        context_in_range = False
        ontology_time = 0
        refinement_time = 0
        generation_time = 0
        error_message = None
        
        try:
            structured_context = row.get("structured_context", "")
            aql_results = row.get("aql_results", "")
            
            ontology = None
            if "without_ontology" not in self.pipeline_type:
                try:
                    self._print_progress("Building ontology", "in_progress")
                    # Use include_ontology_relationships parameter
                    ontology_start = time.time()
                    ontology = self.ontology_agent.process(question, include_relationships=self.include_ontology_relationships)
                    ontology_time = time.time() - ontology_start
                    
                    # Capture ontology statistics
                    if ontology:
                        ontology_attrs = len(ontology.attribute_value_pairs)
                        ontology_rels = len(ontology.logical_relationships)
                        logger.debug(f"Ontology: {ontology_attrs} attributes, {ontology_rels} relationships")
                    
                    # Check if ontology should be used based on question complexity
                    if hasattr(ontology, 'should_use_ontology') and not ontology.should_use_ontology:
                        logger.debug("Simple question - skipping ontology usage for efficiency")
                        ontology = None
                    else:
                        # NEW: Add evaluation features to ontology
                        if hasattr(self.ontology_agent, 'enhance_for_evaluation'):
                            try:
                                documents = row.get("aql_results", "")
                                if documents:
                                    import json
                                    try:
                                        docs_list = json.loads(documents)
                                        evaluation_features = self.ontology_agent.enhance_for_evaluation(docs_list)
                                        # Add features to ontology
                                        for key, value in evaluation_features.items():
                                            setattr(ontology, key, value)
                                    except:
                                        pass
                            except Exception as e:
                                logger.debug(f"Ontology enhancement failed: {e}")
                        
                        result.ontology = ontology  # Store the actual ontology object
                        self._print_progress("Building ontology", "success", f"({ontology_attrs} attributes)")
                except Exception as e:
                    logger.warning(f"Ontology extraction failed: {e}")
                    self._print_progress("Building ontology", "error", f"({str(e)[:50]})")
                    ontology = None
            
            self._print_progress("Refining context", "in_progress")
            include_ontology = "without_ontology" not in self.pipeline_type
            
            # Time refinement step
            refinement_start = time.time()
            
            if "1_pass_with_ontology_refined" in self.pipeline_type:
                assert self.refinement_agent_1pass_refined is not None
                # Use parsed AQL results instead of raw to reduce token count
                parsed_aql_results = result.clean_aql_used if hasattr(result, 'clean_aql_used') and result.clean_aql_used else aql_results
                refined = self.refinement_agent_1pass_refined.process_context(
                    question=question,
                    structured_context=structured_context,
                    ontology=ontology,
                    include_ontology=include_ontology,
                    aql_results_str=parsed_aql_results or None,
                    context_filter=self.context_filter
                )
                # Capture refinement statistics from the refined agent
                if hasattr(refined, 'summary') and 'tokens' in refined.summary:
                    # Use the already logged statistics from the refinement agent
                    # No need to rebuild the prompt and log again
                    refined_context_length = len(refined.enriched_context)
                    refined_context_tokens = refined_context_length // 4
                    context_in_range = 1500 <= refined_context_tokens <= 5000  # Updated to 5000
            elif "1_pass" in self.pipeline_type:
                assert self.refinement_agent_1pass is not None
                refined = self.refinement_agent_1pass.process_context(
                    question=question,
                    structured_context=structured_context,
                    ontology=ontology,
                    include_ontology=include_ontology,
                    aql_results_str=aql_results or None,
                    context_filter=self.context_filter
                )
            
            refinement_time = time.time() - refinement_start
            
            result.refined_context_summary = refined.summary
            final_text_context = refined.enriched_context or structured_context or ""
            
            self._print_progress("Generating answer", "in_progress")
            # Time generation step
            generation_start = time.time()
            
            # NEW: Enable evaluation mode and use proper two-step generation
            answer_obj = self.generation_agent.generate(
                question=question,
                text_context=final_text_context,
                ontology=ontology
            )
            
            generation_time = time.time() - generation_start
            
            # Simple approach: no grounding enforcement, just use generated answer
            # Answer structure is handled by the prompt template
            
            result.answer = answer_obj.answer
            result.references = answer_obj.references
            result.formatted_references = answer_obj.formatted_references
            result.final_text_context = final_text_context
            result.status = "success"
            
            self._print_progress("Generating answer", "success", f"({generation_time:.1f}s)")
        
        except Exception as e:
            result.status = "error"
            result.error_message = str(e)
            result.answer = f"ERROR: {str(e)[:100]}"
            logger.error(f"Question {idx} failed: {e}")
            self._print_progress("Generating answer", "error", f"({str(e)[:50]})")
            if verbose:
                traceback.print_exc()
        
        finally:
            result.time_elapsed = time.time() - start_time
            logger.debug(f"Question {idx} completed in {result.time_elapsed:.2f}s")
            
            # Log comprehensive pipeline analysis
            if hasattr(self, 'pipeline_analyzer'):
                try:
                    # Capture statistics for analysis
                    aql_length = len(aql_results) if aql_results else 0
                    structured_context_length = len(structured_context) if structured_context else 0
                    generation_input_length = len(final_text_context) if final_text_context else 0
                    final_answer_length = len(result.answer) if result.answer else 0
                    
                    # Log to CSV analysis
                    self.pipeline_analyzer.log_pipeline_execution(
                        question_id=idx + 1,  # 1-based index
                        question=question,
                        pipeline_type=self.pipeline_type,
                        ontology_attrs=ontology_attrs,
                        ontology_rels=ontology_rels,
                        aql_length=aql_length,
                        structured_context_length=structured_context_length,
                        refinement_prompt_length=refinement_prompt_length,
                        refined_context_length=refined_context_length,
                        refined_context_tokens=refined_context_tokens,
                        context_in_range=context_in_range,
                        generation_input_length=generation_input_length,
                        final_answer_length=final_answer_length,
                        processing_time=result.time_elapsed,
                        ontology_time=ontology_time,
                        refinement_time=refinement_time,
                        generation_time=generation_time,
                        success=(result.status == "success"),
                        error_msg=result.error_message,
                        notes=f"Refined pipeline with {'relationships' if ontology_rels > 0 else 'no relationships'}"
                    )
                    
                    # Log detailed context analysis for manual review
                    if result.status == "success" and final_text_context and final_text_context != "No refined context generated":
                        ontology_summary = f"{ontology_attrs} attributes, {ontology_rels} relationships" if ontology else "No ontology"
                        self.pipeline_analyzer.log_detailed_context_analysis(
                            question_id=idx + 1,
                            original_context=structured_context,
                            refined_context=final_text_context,
                            ontology_summary=ontology_summary
                        )
                    
                    logger.debug(f"📊 Analysis logged for question {result.original_question_id}")
                except Exception as analysis_error:
                    logger.debug(f"Analysis logging failed: {analysis_error}")
        
        return result

    def _evaluate_result(self, result: PipelineResult) -> Optional[Dict]:
        """
        Evaluate a generated result using DLR framework.
        
        Args:
            result: PipelineResult containing question, answer, and context
            
        Returns:
            Dictionary with evaluation results or None if evaluation fails
        """
        if not self.auto_evaluate or not self.evaluator:
            return None
            
        try:
            # Prepare evaluation data
            question = result.question
            answer = result.answer
            context = result.final_text_context or ""
            
            logger.info(f"🔍 Evaluating answer for question: {question[:50]}...")
            
            # Perform DLR evaluation
            evaluation = self.evaluator.evaluate_answer(question, answer, context)
            
            # Log evaluation result
            overall_score = evaluation.get('overall_score', -1)
            logger.info(f"✅ Evaluation completed - Overall score: {overall_score}/5.0")
            
            # Check for validation anomalies
            if evaluation.get('validation_anomaly', False):
                anomaly_details = evaluation['anomaly_details']
                message = anomaly_details['message']
                severity = anomaly_details.get('severity', 'low')
                
                # Check if this is a perfect score message
                if 'Perfect score achieved' in message:
                    logger.info(f"🎯 {message}")
                else:
                    # Show warning for actual anomalies
                    if severity == 'low':
                        logger.warning(f"⚠️  Evaluation anomaly detected: {message}")
                    else:
                        logger.warning(f"⚠️  Evaluation anomaly detected: {message}")
            
            return evaluation
            
        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return {
                'overall_score': -1,
                'criteria_scores': {c: -1 for c in ['factuality', 'relevance', 'groundedness', 'helpfulness', 'depth']},
                'feedback': f'Evaluation error: {str(e)}',
                'validation_anomaly': True,
                'error': str(e)
            }

    def _save_results(self, results: List[PipelineResult], stats: PipelineStats, output_path: Path, verbose: bool = True):
        # Handle both directory and CSV file output paths
        if output_path.suffix == '.csv':
            # New convention: save directly to standard CSV file
            self._update_csv_with_results(output_path, results)
        else:
            # Legacy behavior: save to directory with multiple files
            for result in results:
                filepath = output_path / f"{result.index:03d}_result.txt"
                self._save_result_file(result, filepath)
            
            json_path = output_path / "results.json"
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump({
                    "pipeline_type": self.pipeline_type,
                    "timestamp": datetime.now().isoformat(),
                    "stats": asdict(stats),
                    "results": [r.to_dict() for r in results],
                }, f, indent=2)
            
            csv_path = output_path / "results.csv"
            if results:
                with open(csv_path, "w", newline="", encoding="utf-8") as f:
                    fieldnames = ["index", "question", "answer", "time_elapsed", "status"]
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for r in results:
                        writer.writerow({
                            "index": r.index,
                            "question": r.question,
                            "answer": r.answer,
                            "time_elapsed": f"{r.time_elapsed:.2f}",
                            "status": r.status,
                        })
            
            summary_path = output_path / "summary.txt"
            self._save_summary_file(stats, summary_path)
        
        if verbose:
            logger.info(f"Results saved to {output_path}")
    
    def _save_results_to_csv(self, results: List[PipelineResult], stats: PipelineStats, csv_path: Path):
        """Save results directly to standard CSV file (new convention)"""
        # Define standard fieldnames for experiment generation results
        fieldnames = [
            'question_id', 'question', 'pipeline', 'context', 'clean_aql_results', 'answer', 'references',
            'formatted_references', 'processing_time', 'documents_parsed', 'timestamp', 'experiment_type',
            'factuality', 'relevance', 'groundedness', 'helpfulness', 'depth',
            'overall_score', 'evaluation_feedback', 'validation_anomaly', 'anomaly_details'
        ]
        
        # Prepare rows for CSV
        rows = []
        for result in results:
            # Extract clean AQL results from the result object if available
            clean_aql_results = ''
            if hasattr(result, 'clean_aql_used') and result.clean_aql_used:
                clean_aql_results = result.clean_aql_used
            
            row = {
                'question_id': result.original_question_id,  # Use original question ID from input CSV
                'question': result.question,
                'pipeline': self.pipeline_type,
                'context': result.final_text_context or '',
                'clean_aql_results': clean_aql_results,
                'answer': result.answer,
                'references': ' | '.join(result.references) if result.references else '',
                'formatted_references': ' | '.join(result.formatted_references) if result.formatted_references else '',
                'processing_time': f"{result.time_elapsed:.2f}",
                'documents_parsed': len([d for d in result.final_text_context.split('##') if d.strip()]) if result.final_text_context else 0,
                'timestamp': datetime.now().isoformat(),
                'experiment_type': getattr(self, 'experiment_type', '')
            }
            
            # Add evaluation results if available
            if hasattr(result, 'evaluation') and result.evaluation:
                eval_result = result.evaluation
                row.update({
                    'factuality': eval_result['criteria_scores']['factuality'],
                    'relevance': eval_result['criteria_scores']['relevance'],
                    'groundedness': eval_result['criteria_scores']['groundedness'],
                    'helpfulness': eval_result['criteria_scores']['helpfulness'],
                    'depth': eval_result['criteria_scores']['depth'],
                    'overall_score': eval_result['overall_score'],
                    'evaluation_feedback': eval_result['feedback'][:200] if eval_result['feedback'] else '',
                    'validation_anomaly': eval_result.get('validation_anomaly', False)
                })
                
                # Add anomaly details if present
                if eval_result.get('anomaly_details'):
                    row['anomaly_details'] = json.dumps(eval_result['anomaly_details'])
            else:
                # Add placeholder evaluation fields for consistency
                row.update({
                    'factuality': '',
                    'relevance': '',
                    'groundedness': '',
                    'helpfulness': '',
                    'depth': '',
                    'overall_score': '',
                    'evaluation_feedback': '',
                    'validation_anomaly': False
                })
            
            rows.append(row)
        
        # Write to CSV (overwrite entire file only if overwrite flag is set)
        if self.overwrite or not os.path.exists(csv_path):
            # Overwrite entire file
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
        else:
            # Append to existing file
            with open(csv_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                # Only write header if file is empty
                if os.path.getsize(csv_path) == 0:
                    writer.writeheader()
                writer.writerows(rows)
        
        logger.info(f"Saved {len(rows)} results to {csv_path}")
    
    def _update_csv_with_results(self, csv_path: str, results: List[PipelineResult]):
        """Update existing CSV with new results - uses new conventions"""
        try:
            # Define the standard fieldnames for the CSV
            fieldnames = [
                'question_id', 'question', 'pipeline', 'context', 'clean_aql_results', 'answer', 'references',
                'formatted_references', 'processing_time', 'documents_parsed', 'timestamp', 'experiment_type',
                'factuality', 'relevance', 'groundedness', 'helpfulness', 'depth',
                'overall_score', 'evaluation_feedback', 'validation_anomaly', 'anomaly_details'
            ]
            
            # Check if file exists and read existing data
            existing_rows = []
            if os.path.exists(csv_path):
                with open(csv_path, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    existing_rows = list(reader)
            
            # Update or add new results
            for result in results:
                question_id = result.original_question_id
                
                # Check if this question already exists for this pipeline and experiment type
                existing_row = None
                existing_row_index = -1
                for i, row in enumerate(existing_rows):
                    if (int(row.get('question_id', 0)) == question_id and 
                        row.get('pipeline') == self.pipeline_type and
                        row.get('experiment_type') == getattr(self, 'experiment_type', '')):
                        existing_row = row
                        existing_row_index = i
                        break
                
                logger.debug(f"Processing question {question_id}, pipeline {self.pipeline_type}, experiment_type '{getattr(self, 'experiment_type', '')}'")
                logger.debug(f"Found existing row: {existing_row is not None}")
                if existing_row:
                    logger.debug(f"Existing row experiment_type: '{existing_row.get('experiment_type', '')}'")
                
                # If no exact match found and we're overwriting, remove all rows with same question_id and pipeline
                if not existing_row and self.overwrite:
                    logger.debug(f"Removing old rows for question {question_id}, pipeline {self.pipeline_type}")
                    old_count = len(existing_rows)
                    existing_rows = [row for row in existing_rows if not (
                        int(row.get('question_id', 0)) == question_id and 
                        row.get('pipeline') == self.pipeline_type
                    )]
                    new_count = len(existing_rows)
                    logger.debug(f"Removed {old_count - new_count} old rows")
                
                # Create row data
                row_data = {
                    'question_id': question_id,
                    'question': result.question,
                    'pipeline': self.pipeline_type,
                    'context': result.final_text_context or '',
                    'answer': result.answer,
                    'references': ' | '.join(result.references) if result.references else '',
                    'formatted_references': ' | '.join(result.formatted_references) if result.formatted_references else '',
                    'processing_time': f"{result.time_elapsed:.2f}",
                    'documents_parsed': len([d for d in result.final_text_context.split('##') if d.strip()]) if result.final_text_context else 0,
                    'timestamp': datetime.now().isoformat(),
                    'experiment_type': getattr(self, 'experiment_type', '')
                }
                
                # Add evaluation results if available
                if hasattr(result, 'evaluation') and result.evaluation:
                    eval_result = result.evaluation
                    row_data.update({
                        'factuality': eval_result['criteria_scores']['factuality'],
                        'relevance': eval_result['criteria_scores']['relevance'],
                        'groundedness': eval_result['criteria_scores']['groundedness'],
                        'helpfulness': eval_result['criteria_scores']['helpfulness'],
                        'depth': eval_result['criteria_scores']['depth'],
                        'overall_score': eval_result['overall_score'],
                        'evaluation_feedback': eval_result['feedback'][:200] if eval_result['feedback'] else '',
                        'validation_anomaly': eval_result.get('validation_anomaly', False)
                    })
                    
                    # Add anomaly details if present
                    if eval_result.get('anomaly_details'):
                        row_data['anomaly_details'] = json.dumps(eval_result['anomaly_details'])
                else:
                    # Add placeholder evaluation fields for consistency
                    row_data.update({
                        'factuality': '',
                        'relevance': '',
                        'groundedness': '',
                        'helpfulness': '',
                        'depth': '',
                        'overall_score': '',
                        'evaluation_feedback': '',
                        'validation_anomaly': False
                    })
                
                # Update existing row or add new one
                if existing_row:
                    logger.debug(f"Overwriting existing row at index {existing_row_index}")
                    existing_rows[existing_row_index] = row_data
                else:
                    logger.debug(f"Appending new row")
                    existing_rows.append(row_data)
            
            # Sort the rows by question_id to maintain order
            existing_rows.sort(key=lambda x: int(x['question_id']))
            
            # Write updated data back to CSV
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(existing_rows)
            
            logger.debug(f"Updated CSV: {csv_path}")
        except Exception as e:
            logger.error(f"Failed to update CSV: {e}")
    
    def _save_result_file(self, result: PipelineResult, filepath: Path):
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"Question {result.index}: {result.question}\n")
            f.write("=" * 80 + "\n\n")
            f.write("ANSWER\n")
            f.write(f"{result.answer}\n\n")
            f.write(f"Execution Time: {result.time_elapsed:.2f}s\n")
            f.write(f"Status: {result.status}\n")
            if result.error_message:
                f.write(f"Error: {result.error_message}\n")
            if result.ontology:
                f.write(f"\n{result.ontology}\n")
            if result.refined_context_summary:
                f.write(f"\nSUMMARY: {result.refined_context_summary}\n")
            if result.final_text_context:
                f.write(f"\nTEXT CONTEXT:\n{result.final_text_context}\n")

    def _save_summary_file(self, stats: PipelineStats, filepath: Path):
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write("PIPELINE EXECUTION SUMMARY\n")
            f.write("=" * 80 + "\n")
            f.write(f"Pipeline Type: {self.PIPELINE_TYPES[self.pipeline_type]}\n")
            f.write(f"Timestamp: {datetime.now().isoformat()}\n\n")
            f.write("STATISTICS\n")
            f.write(f" Total Questions: {stats.total}\n")
            f.write(f" Successful: {stats.successful} ({stats.successful/max(1, stats.total)*100:.1f}%)\n")
            f.write(f" Failed: {stats.failed} ({stats.failed/max(1, stats.total)*100:.1f}%)\n\n")
            f.write("PERFORMANCE\n")
            f.write(f" Average Time: {stats.avg_time:.2f}s\n\n")
            f.write("OUTPUT FILES\n")
            f.write(" - results.json: all results as JSON\n")
            f.write(" - results.csv: summary table\n")
            f.write(" - NNN_result.txt: individual results\n")

    def _format_ontology(self, ontology) -> str:
        lines = ["ONTOLOGY"]
        if hasattr(ontology, "attribute_value_pairs"):
            lines.append(f" Attributes: {len(ontology.attribute_value_pairs)}")
            for av in ontology.attribute_value_pairs[:3]:
                lines.append(f" - {av.attribute}: {av.value} (centrality: {av.centrality:.2f})")
        if hasattr(ontology, "logical_relationships"):
            lines.append(f" Relationships: {len(ontology.logical_relationships)}")
        return "\n".join(lines)

    def _print_header(self, data: List[Dict]):
        print("=" * 80)
        print("ORCHESTRATOR - MULTI-PIPELINE TEST RUNNER")
        print("=" * 80)
        print(f"Pipeline Type: {self.PIPELINE_TYPES[self.pipeline_type]}")
        print(f"Questions to Process: {len(data)}")
        print("=" * 80)
    
    def _print_progress(self, step: str, status: str, details: str = ""):
        """Print clean, user-facing progress updates."""
        if status == "in_progress":
            print(f"  • {step}...")
        elif status == "success":
            print(f"    ✓ {step} {details}")
        elif status == "warning":
            print(f"    ⚠ {step} {details}")
        elif status == "error":
            print(f"    ✗ {step} {details}")

    def _print_summary(self, stats: PipelineStats, output_path: Path):
        print("=" * 80)
        print("EXECUTION COMPLETE")
        print("=" * 80)
        print(f"Total: {stats.total} | Successful: {stats.successful} | Failed: {stats.failed}")
        print(f"Avg Time: {stats.avg_time:.2f}s")
        print(f"Output: {output_path}")
        print("=" * 80)
        print("📝 Detailed logs saved to: pipeline_debug.log")

def main():
    parser = argparse.ArgumentParser(
        description="Multi-Pipeline Orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
python3 orchestrator.py run --type 1_pass_with_ontology --csv data.csv --num 3
python3 orchestrator.py run --type 2_pass_with_ontology --csv data.csv --save-to-csv
python3 orchestrator.py run --type 1_pass_with_ontology --csv data.csv --num 5 --model mistral-small-latest
python3 orchestrator.py run --type 1_pass_with_ontology_refined --csv data.csv --num 5 --output-csv results_to_be_processed/refined-context_results_v2
"""
    )
    
    parser.add_argument("action", choices=["run"], help="Action to perform")
    parser.add_argument("--type", required=True, choices=list(PipelineOrchestrator.PIPELINE_TYPES.keys()), help="Pipeline type to run")
    parser.add_argument("--csv", required=True, help="Path to input CSV file")
    parser.add_argument("--num", type=int, default=None, help="Number of questions to process")
    parser.add_argument("--output", default=None, help="Output directory or CSV file path")
    parser.add_argument("--save-to-csv", action="store_true", help="Update CSV file with answers")
    parser.add_argument("--output-csv", default=None, help="Custom output CSV filename (overrides default naming)")
    parser.add_argument("--indices", type=int, nargs="+", default=None, help="Specific row indices to process")
    parser.add_argument("--quiet", action="store_true", help="Minimal output")
    parser.add_argument("--dlr-compatible", action="store_true", help="Use DLR-compatible generation prompt for better groundedness")
    parser.add_argument("--hybrid-models", action="store_true", help="Use mistral-small-latest for all tasks (legacy hybrid mode)")
    parser.add_argument("--model", default="mistral-small-latest", help="Model name to use for generation (default: mistral-small-latest)")
    parser.add_argument("--context-filter", default="full", choices=["full", "slim", "scores_only"], help="Context filter type: full, slim, or scores_only")
    parser.add_argument("--experiment-type", default="default", help="Experiment variant (default, slim_ontology, scores_only)")
    parser.add_argument("--include-relationships", action="store_true", help="Include ontology relationships (disabled by default for efficiency)")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing results (disables anti-re-evaluation)")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging (shows detailed debug information)")
    parser.add_argument("--show-tokens", action="store_true", help="Show token estimates and prompt statistics")
    parser.add_argument("--refinement-temp", type=float, default=0.1, help="Temperature for refinement agent (default: 0.1)")
    parser.add_argument("--generation-temp", type=float, default=0.2, help="Temperature for generation agent (default: 0.2)")
    parser.add_argument("--auto-evaluate", action="store_true", help="Enable automatic DLR evaluation after generation")
    parser.add_argument("--evaluation-model", default="gpt-4.1-mini", help="Model to use for evaluation (default: gpt-4.1-mini)")
    
    args = parser.parse_args()
    
    # Adjust logging levels based on flags
    if args.verbose:
        console_handler.setLevel(logging.DEBUG)
        logger.info("🔍 Verbose mode enabled - showing detailed logs")
    
    if not args.show_tokens:
        # Suppress token-related logs unless explicitly requested
        logging.getLogger("core.agents.refinement_agent_1pass").setLevel(logging.INFO)
        logging.getLogger("core.agents.generation_agent").setLevel(logging.INFO)
    
    orchestrator = PipelineOrchestrator(
        args.type, 
        model_name=args.model, 
        use_dlr_compatible=args.dlr_compatible, 
        use_hybrid_models=args.hybrid_models,
        context_filter=args.context_filter,
        include_ontology_relationships=args.include_relationships,
        experiment_type=args.experiment_type,
        overwrite=args.overwrite,
        refinement_temperature=args.refinement_temp,
        generation_temperature=args.generation_temp,
        auto_evaluate=args.auto_evaluate,
        evaluation_model=args.evaluation_model
    )
    results, output_dir, stats = orchestrator.run(
        input_csv=args.csv,
        num_questions=args.num,
        output_dir=args.output,
        output_csv=args.output_csv,
        save_to_csv=args.save_to_csv,
        verbose=not args.quiet,
        indices=args.indices,
    )
    
    sys.exit(0 if stats.failed == 0 else 1)

if __name__ == "__main__":
    main()
