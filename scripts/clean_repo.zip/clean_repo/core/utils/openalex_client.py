"""
OpenAlex API client for fetching metadata from OpenAlex URIs.
Clean, efficient, and non-intrusive implementation.
"""

import requests
from typing import Dict, Optional
import logging
import time

# Configure logging
logger = logging.getLogger(__name__)

class OpenAlexClient:
    """Client for fetching metadata from OpenAlex API."""
    
    BASE_URL = "https://api.openalex.org/works/"
    
    @classmethod
    def fetch_metadata(cls, uri: str) -> Optional[Dict[str, str]]:
        """
        Fetch metadata (author, year) from an OpenAlex URI.
        
        Args:
            uri: OpenAlex URI (e.g., "https://openalex.org/W1972149254").
        
        Returns:
            Dict with keys: "author", "year", "title", "uri".
            Returns None if the request fails.
        """
        if not uri or "openalex.org" not in uri:
            logger.warning(f"Invalid OpenAlex URI: {uri}")
            return None
        
        # Extract work ID from URI (e.g., "W1972149254")
        work_id = uri.split("/")[-1]
        if not work_id:
            logger.warning(f"Could not extract work ID from URI: {uri}")
            return None
        
        max_retries = 3
        retry_delay = 1  # seconds
        
        for attempt in range(max_retries):
            try:
                response = requests.get(f"{cls.BASE_URL}{work_id}", timeout=5)
                response.raise_for_status()
                data = response.json()
                
                # Extract metadata
                author = "No author"
                if data.get("authorships"):
                    first_author = data["authorships"][0].get("author", {})
                    author = first_author.get("display_name", "No author")
                
                year = data.get("publication_year", "No year")
                title = data.get("title", "No title")
                
                return {
                    "author": author,
                    "year": str(year) if year else "No year",
                    "title": title,
                    "uri": uri,
                }
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 404:
                    logger.warning(f"URL not found for {uri}: {e}. No retry.")
                    return None
                elif attempt < max_retries - 1:
                    logger.warning(f"Attempt {attempt + 1} failed for {uri}: {e}. Retrying...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.warning(f"Failed to fetch metadata for {uri} after {max_retries} attempts: {e}")
                    return None
            except requests.exceptions.RequestException as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Attempt {attempt + 1} failed for {uri}: {e}. Retrying...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.warning(f"Failed to fetch metadata for {uri} after {max_retries} attempts: {e}")
                    return None
            except Exception as e:
                logger.error(f"Unexpected error fetching metadata for {uri}: {e}")
                return None


def format_reference_from_metadata(metadata: Dict[str, str]) -> str:
    """
    Format a reference string from metadata.
    
    Args:
        metadata: Dict with keys: "author", "year", "title", "uri".
    
    Returns:
        Formatted reference string (e.g., "[1] Author et al. (Year). *Title*. URI.").
    """
    author = metadata.get("author", "No author")
    year = metadata.get("year", "No year")
    title = metadata.get("title", "No title")
    uri = metadata.get("uri", "No URI")
    
    return f"[{metadata.get('position', 1)}] {author} ({year}). *{title}*. {uri}."
