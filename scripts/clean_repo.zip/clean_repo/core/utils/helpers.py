"""helper functions for the multi-agent system."""

import os
import json
import re
import logging
from dotenv import load_dotenv
from mistralai import Mistral

load_dotenv()


class MistralLLMWrapper:
    """Wrapper for Mistral API with structured output support."""

    def __init__(self, client, model: str = "mistral-small-latest", temperature: float = 0.3):
        self.client = client
        self.model = model
        self.temperature = temperature

    def invoke(self, prompt_text: str, force_json: bool = False):
        """Call the LLM and return response. If force_json=True, enforce JSON output."""
        if force_json:
            system_instruction = (
                "You MUST respond with ONLY valid JSON when instructed to do so. \n"
            )
            full_prompt = system_instruction + prompt_text
        else:
            # For text responses, use clean prompt without JSON constraints
            full_prompt = prompt_text
        
        messages = [{"role": "user", "content": full_prompt}]

        try:
            response = self.client.chat.complete(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=8000,
            )
            content = response.choices[0].message.content

            return self._parse_output(content, force_json=force_json)
       
        except Exception as e:
            logging.error(f"LLM call failed: {e}")
            return None
    
    def with_structured_output(self, schema):
        """Return a version of the LLM that enforces structured output."""
        # Store the schema for reference
        self._structured_schema = schema
        return self
    
    def invoke_with_schema(self, messages):
        """Invoke LLM with structured output enforcement."""
        try:
            # Convert messages to Mistral format
            mistral_messages = []
            for message in messages:
                if hasattr(message, 'content'):
                    mistral_messages.append({"role": "user", "content": message.content})
                elif isinstance(message, dict):
                    mistral_messages.append({"role": message.get("role", "user"), "content": message.get("content", "")})
            
            # Add system instruction for structured output
            if hasattr(self, '_structured_schema') and self._structured_schema:
                schema_desc = self._get_schema_description()
                system_instruction = (
                    f"You MUST respond with ONLY valid JSON matching this schema: {schema_desc}\n"
                    "NEVER include any additional text, explanations, or markdown formatting.\n"
                    "ONLY return the raw JSON object."
                )
                mistral_messages.insert(0, {"role": "system", "content": system_instruction})
            
            response = self.client.chat.complete(
                model=self.model,
                messages=mistral_messages,
                temperature=0.3,
                max_tokens=8000,
            )
            content = response.choices[0].message.content
            
            # Parse and validate against schema (force JSON for structured output)
            parsed = self._parse_output(content, force_json=True)
            if parsed and hasattr(self, '_structured_schema'):
                # Validate against schema if needed
                return self._validate_against_schema(parsed)
            
            # If JSON parsing failed but we have content, return the raw content
            # This allows the calling code to parse it manually
            if parsed is None and content:
                return content
            
            return parsed
            
        except Exception as e:
            logging.error(f"Structured LLM call failed: {e}")
            return None
    
    def _get_schema_description(self):
        """Get a description of the expected schema."""
        if hasattr(self, '_structured_schema'):
            return str(self._structured_schema)
        return "JSON object"
    
    def _validate_against_schema(self, data):
        """Basic validation against schema."""
        # For now, just return the data as-is
        # In a full implementation, we'd validate against the schema
        return data

    def _parse_output(self, content: str, force_json: bool = False):
        """Extract JSON or return raw content if not JSON."""
        try:
            content = re.sub(r"```json\n?", "", content)
            content = re.sub(r"```\n?", "", content).strip()
            
            if not content:
                logging.error("Empty content")
                return None
            
            # If force_json is False, return raw text content
            if not force_json:
                return content
            
            # Try to parse as JSON first (only when force_json=True)
            try:
                data = json.loads(content)
                
                if isinstance(data, list):
                    data = {"assessments": data}
                
                return data
            except json.JSONDecodeError:
                # If JSON parsing fails, check if it's a JSON-like structure with markdown key
                if content.strip().startswith('{') and 'markdown' in content:
                    # Try to extract the markdown content
                    import ast
                    try:
                        parsed = ast.literal_eval(content)
                        if isinstance(parsed, dict) and 'markdown' in parsed:
                            return parsed['markdown']
                    except:
                        pass
                
                # If not JSON but force_json=True, log error and return None
                logging.error("JSON parsing failed, but force_json=True was set")
                return None
        
        except (TypeError, ValueError) as e:
            logging.error(f"Parse failed: {type(e).__name__}: {e}")
            logging.debug(f"Content: {content[:300]}")
            return None


def get_llm_model(model: str = "mistral-small-latest", temperature: float = 0.3) -> MistralLLMWrapper:
    """Initialize and return Mistral LLM wrapper."""
    api_key = os.getenv("MISTRAL_API_KEY")
    if not api_key:
        raise ValueError("MISTRAL_API_KEY not found in .env")
    client = Mistral(api_key=api_key)
    # Use the specified model and temperature
    return MistralLLMWrapper(client, model=model, temperature=temperature)


def setup_logging(name: str, level: str = "INFO") -> logging.Logger:
    """Setup logger for module."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger