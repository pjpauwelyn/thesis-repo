# utils/data_models.py

from typing import List, Dict, Optional, Literal, Any
from pydantic import BaseModel, Field
from datetime import datetime

class AttributeValuePair(BaseModel):
    attribute: str = Field(..., description="Attribute concept")
    value: str = Field(..., description="Specific value")
    description: str = Field(..., description="Explanation")
    value_type: Literal["numeric", "categorical", "temporal", "spatial"] = "categorical"
    constraints: List[str] = Field(default_factory=list)
    centrality: float = Field(..., ge=0.0, le=1.0, description="Centrality score (0-1)")

class LogicalRelationship(BaseModel):
    source_attribute: str = Field(...)
    source_value: str = Field(...)
    target_attribute: str = Field(...)
    target_value: str = Field(...)
    relationship_type: str = Field(..., description="influences, causes, requires, etc.")
    logical_constraint: str = Field(...)

class DynamicOntology(BaseModel):
    attribute_value_pairs: List[AttributeValuePair] = Field(...)
    logical_relationships: List[LogicalRelationship] = Field(...)
    source_query: str = Field(...)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    should_use_ontology: bool = Field(default=True, description="Whether ontology should be used for this question")
    include_relationships: bool = Field(default=True, description="Whether to include logical relationships")

    def get_critical_attributes(self, threshold: float = 0.8) -> List[AttributeValuePair]:
        return [av for av in self.attribute_value_pairs if av.centrality >= threshold]

    def get_contextual_attributes(self, threshold: float = 0.4) -> List[AttributeValuePair]:
        return [av for av in self.attribute_value_pairs if av.centrality >= threshold]

class DocumentAssessment(BaseModel):
    id: Optional[str] = None
    title_or_name: str = Field(...)
    position: int = Field(...)
    type: Literal["publication", "keyword"] = Field(...)
    relevance_score: float = Field(..., ge=0.0, le=1.0)
    scope: str = Field(...)
    caveats: str = Field(...)
    instruction: str = Field(...)
    include: bool = Field(default=True, description="Whether to include this document in final context")
    geographic_scope: Optional[str] = Field(default=None, description="Geographic scope of the document")
    geographic_match: Optional[str] = Field(default=None, description="How well geographic scope matches query")
    temporal_scope: Optional[str] = Field(default=None, description="Temporal scope of the document")
    temporal_match: Optional[str] = Field(default=None, description="How well temporal scope matches query")
    what_is_relevant: Optional[str] = Field(default=None, description="What content is relevant")
    context_limitations: Optional[str] = Field(default=None, description="Limitations of the context")
    raw_metrics_text: Optional[str] = Field(default=None, description="Raw metrics text")
    spatial_context_text: Optional[str] = Field(default=None, description="Spatial context text")
    temporal_context_text: Optional[str] = Field(default=None, description="Temporal context text")
    supporting_details_text: Optional[str] = Field(default=None, description="Supporting details text")
    generation_instruction: Optional[str] = Field(default=None, description="Generation instruction")
    citation: Optional[str] = Field(default=None, description="Formatted citation (Author et al., Year) or (Document Title, Year)")
    full_reference: Optional[str] = Field(default=None, description="Complete reference for references section")
    reference_id: Optional[str] = Field(default=None, description="Reference ID for citation markers (e.g., [Smith2020])")

class RefinedContext(BaseModel):
    original_context: str = Field(...)
    question: str = Field(...)
    ontology_summary: str = Field(...)
    assessments: List[DocumentAssessment] = Field(...)
    summary: str = Field(...)
    enriched_context: Optional[str] = None
    enriched_documents: Optional[List[Dict[str, Any]]] = None

    def get_included_assessments(self) -> List[DocumentAssessment]:
        return [a for a in self.assessments if a.include]

    def get_excluded_assessments(self) -> List[DocumentAssessment]:
        return [a for a in self.assessments if not a.include]

    def get_sorted_by_relevance(self) -> List[DocumentAssessment]:
        return sorted(self.get_included_assessments(), key=lambda a: a.relevance_score, reverse=True)
