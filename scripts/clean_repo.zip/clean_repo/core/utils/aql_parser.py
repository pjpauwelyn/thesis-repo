# aql_parser.py
# Independent AQL Results Parser Layer
# (Standalone implementation for testing before core integration)

import ast
import json
from typing import List, Dict, Any


def parse_aql_results(aql_results_str: str) -> str:
    """
    Parse raw AQL results and extract only essential information for RAG.
    
    Keeps: title, abstract, uri for each document
    Drops: science_keywords, secondary_nodes, and all nested structures
    
    Args:
        aql_results_str: Raw AQL results string from CSV (Python repr format)
        
    Returns:
        Clean JSON string with only essential document info (compact format)
        
    Expected size reduction: ~93% (from ~386KB to ~8-12KB per question)
    """
    if not aql_results_str or aql_results_str.strip() == '':
        return '[]'  # Empty but valid JSON
    
    try:
        # Parse the malformed JSON (Python repr format with single quotes)
        data = ast.literal_eval(aql_results_str)
        
        # Validate that we have a list of documents
        if not isinstance(data, list):
            return json.dumps([], separators=(',', ':'))
        
        # Extract only essential fields, drop everything else
        clean_docs = []
        for doc in data:
            if not isinstance(doc, dict):
                continue
                
            # Build clean document with only what we need
            clean_doc = {
                'title': doc.get('title', ''),
                'abstract': doc.get('abstract', ''),
                'uri': doc.get('uri', '')
                # Explicitly excluding: science_keywords, secondary_nodes, etc.
            }
            clean_docs.append(clean_doc)
        
        # Return as compact JSON (no whitespace for minimal size)
        return json.dumps(clean_docs, separators=(',', ':'))
        
    except Exception as e:
        # If parsing fails, return a safe fallback
        return json.dumps({
            'error': f'AQL parsing failed: {str(e)}',
            'original_length': len(aql_results_str)
        }, separators=(',', ':'))


def analyze_aql_results(aql_results_str: str) -> Dict[str, Any]:
    """
    Analyze AQL results to show the parsing improvement.
    
    Returns statistics about the original vs parsed size.
    """
    original_size = len(aql_results_str)
    parsed_size = len(parse_aql_results(aql_results_str))
    
    try:
        data = ast.literal_eval(aql_results_str)
        doc_count = len(data) if isinstance(data, list) else 0
        
        # Count actual content
        content_chars = 0
        for doc in data:
            if isinstance(doc, dict):
                content_chars += len(doc.get('title', '')) + len(doc.get('abstract', '')) + len(doc.get('uri', ''))
        
        return {
            'original_size': original_size,
            'parsed_size': parsed_size,
            'reduction_percentage': (1 - parsed_size/original_size) * 100 if original_size > 0 else 0,
            'reduction_factor': original_size/parsed_size if parsed_size > 0 else 0,
            'document_count': doc_count,
            'content_chars': content_chars,
            'overhead_chars': original_size - content_chars,
            'overhead_percentage': (1 - content_chars/original_size) * 100 if original_size > 0 else 0
        }
    except:
        return {
            'original_size': original_size,
            'parsed_size': parsed_size,
            'error': 'Could not analyze original structure'
        }


def test_parser_on_csv(csv_path: str, num_rows: int = 5) -> List[Dict[str, Any]]:
    """
    Test the parser on multiple rows from a CSV file.
    
    Args:
        csv_path: Path to input CSV file
        num_rows: Number of rows to test
        
    Returns:
        List of analysis results for each row
    """
    import csv
    csv.field_size_limit(int(1e8))
    
    results = []
    
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            for i, row in enumerate(reader):
                if i >= num_rows:
                    break
                    
                aql_results = row.get('aql_results', '')
                
                if aql_results:
                    analysis = analyze_aql_results(aql_results)
                    analysis['row_index'] = i
                    analysis['question_id'] = row.get('question_id', str(i+1))
                    analysis['question_preview'] = row.get('question', '')[:50] + '...'
                    
                    # Show sample of parsed output
                    parsed = parse_aql_results(aql_results)
                    analysis['parsed_preview'] = parsed[:200] + '...' if len(parsed) > 200 else parsed
                    
                    results.append(analysis)
    
    except Exception as e:
        results.append({
            'error': f'CSV testing failed: {str(e)}',
            'row_index': -1
        })
    
    return results


def get_clean_aql_sample(aql_results_str: str, max_docs: int = 3) -> str:
    """
    Get a formatted sample of what the clean AQL looks like.
    
    Useful for manual inspection and validation.
    """
    try:
        data = ast.literal_eval(aql_results_str)
        
        # Get first few documents with formatting
        sample_docs = []
        for i, doc in enumerate(data[:max_docs]):
            sample_docs.append({
                'id': i + 1,
                'title': doc.get('title', '')[:80] + '...' if len(doc.get('title', '')) > 80 else doc.get('title', ''),
                'abstract': doc.get('abstract', '')[:150] + '...' if len(doc.get('abstract', '')) > 150 else doc.get('abstract', ''),
                'uri': doc.get('uri', '')
            })
        
        # Return pretty-printed for inspection
        return json.dumps(sample_docs, indent=2)
        
    except:
        return "Could not generate sample"


if __name__ == "__main__":
    # Standalone testing
    print("AQL Parser - Standalone Test")
    print("=" * 50)
    
    # Test with sample data
    sample_aql = "[{'title': 'Test Paper', 'abstract': 'This is a test abstract...', 'uri': 'https://test.org/123', 'science_keywords': [{'name': 'test', 'description': 'test desc'}]}]"
    
    print(f"Original: {len(sample_aql)} chars")
    print(f"Original: {sample_aql}")
    
    parsed = parse_aql_results(sample_aql)
    print(f"\nParsed: {len(parsed)} chars")
    print(f"Parsed: {parsed}")
    
    analysis = analyze_aql_results(sample_aql)
    print(f"\nAnalysis: {analysis}")