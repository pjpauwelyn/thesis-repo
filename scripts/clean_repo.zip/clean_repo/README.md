# 1-Pass Refined Pipeline - Clean Repository

A streamlined multi-agent system for Earth Observation question answering using ontology-enhanced retrieval-augmented generation with 1-pass refined processing.

## Repository Structure

```
clean_repo/
├── core/                  # Core system components
│   ├── agents/            # Individual agent implementations
│   └── utils/             # Utility functions and data models
├── prompts/              # Prompt templates for all agents
│   ├── generation/        # Generation prompt templates
│   ├── ontology/          # Ontology extraction prompts
│   └── refinement/        # Context refinement prompts
├── scripts/              # Utility and analysis scripts
├── evaluation/           # Evaluation scripts and results
├── experiments/          # Experiment configurations
├── results/              # Processed results
├── tests/                # Test suite
└── docs/                 # Documentation
```

## Key Components

### 1. Core System (`core/`)
- **main.py**: Main pipeline orchestrator
- **agents/**: Individual agent implementations
  - `ontology_agent.py`: Ontology construction agent
  - `refinement_agent_1pass_refined.py`: Context refinement agent (1-pass refined)
  - `generation_agent.py`: Answer generation agent
  - `base_agent.py`: Base agent class
  - `base_refinement_agent.py`: Base refinement agent class
- **utils/**: Utility functions and data models
  - `data_models.py`: Data structures and models
  - `openalex_client.py`: OpenAlex API client
  - `aql_parser.py`: AQL results parser

### 2. Prompts (`prompts/`)
- **generation/**: Generation prompt templates
  - `generation_prompt_exp4.txt`: Main generation prompt
- **ontology/**: Ontology extraction prompts
  - `extract_attributes.txt`: Attribute extraction prompt
- **refinement/**: Context refinement prompts
  - `refinement_1pass_refined_exp4.txt`: 1-pass refined refinement prompt

### 3. Scripts (`scripts/`)
- `check_unique_questions.py`: Check for unique questions
- `validation_evaluation.py`: Validation and evaluation scripts

## Pipeline Overview

The 1-pass refined pipeline uses an AQL-only approach where the LLM extracts both findings and references directly from AQL results, creating a compact and efficient processing flow.

### Data Flow

```
Input CSV → Ontology Construction → Context Refinement → Answer Generation → Output
```

### Key Features

- **AQL-only approach**: LLM extracts findings and references directly from AQL results
- **Compact refinement**: Creates perfect context for generation agent
- **Efficient processing**: Reduced token usage and improved performance
- **Comprehensive logging**: Detailed debug and performance logging
- **Context size validation**: Ensures refined context stays within target range (1500-5000 tokens)

## Usage

### Running the Pipeline

```bash
cd clean_repo
python core/main.py run --type 1_pass_with_ontology_refined --csv data.csv --num 5
```

### Key Commands

```bash
# Run 1-pass refined pipeline
python core/main.py run --type 1_pass_with_ontology_refined --csv input.csv --num 10

# Run with specific model
python core/main.py run --type 1_pass_with_ontology_refined --csv input.csv --model mistral-small-latest --num 5

# Run with verbose logging
python core/main.py run --type 1_pass_with_ontology_refined --csv input.csv --num 3 --verbose

# Run with auto-evaluation
python core/main.py run --type 1_pass_with_ontology_refined --csv input.csv --num 5 --auto-evaluate
```

### Pipeline Types

- `1_pass_with_ontology_refined`: 1-Pass with Ontology Refined (main pipeline)
- `1_pass_with_ontology`: 1-Pass with Ontology (standard)
- `1_pass_without_ontology`: 1-Pass without Ontology

### Common Flags

- `--num`: Number of questions to process
- `--model`: Model name to use for generation
- `--verbose`: Enable verbose logging
- `--auto-evaluate`: Enable automatic DLR evaluation
- `--overwrite`: Overwrite existing results
- `--context-filter`: Context filter type (full, slim, scores_only)
- `--refinement-temp`: Temperature for refinement agent
- `--generation-temp`: Temperature for generation agent

## Key Functionality

### Ontology Construction
- Extracts critical and contextual attributes from questions
- Sorts attributes by relevance (centrality)
- Creates compact ontology representation for prompts

### Context Refinement
- Uses AQL-only approach for efficient processing
- Extracts both findings and references from AQL results
- Validates context size (1500-5000 tokens target range)
- Creates minimal document assessments for compatibility

### Answer Generation
- Uses refined context for answer generation
- Produces structured answers with references
- Includes comprehensive error handling and logging

## Performance Monitoring

The system includes real-time performance monitoring with:
- Processing time tracking
- Success rate monitoring
- Error rate detection
- Performance alerts for slow processing or low success rates

## Logging

- **pipeline_debug.log**: Detailed debug and performance logs
- **raw_prompts_debug.log**: Full prompt logging for debugging
- Console output: Clean, user-friendly progress updates

## Testing

Run tests with:

```bash
cd clean_repo
pytest tests/
```

## Cleanup and Organization

The repository has been cleaned up to:
- Remove duplicate and unused files
- Organize code into logical directories
- Standardize naming conventions
- Remove unnecessary comments and verbosity
- Ensure all comments use lowercase format
- Maintain consistent code style throughout

## License

This project is licensed under the MIT License.