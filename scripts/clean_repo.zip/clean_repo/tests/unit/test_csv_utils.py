# tests/unit/test_csv_utils.py

import pytest
import os
import sys
import csv
import tempfile
from pathlib import Path

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'core'))

from core.main import PipelineOrchestrator


def test_csv_path_handling():
    """Test that CSV utilities build correct paths into results_to_be_processed/."""
    
    # Create temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        # Mock the results directory
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create results directory
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Test that orchestrator creates correct paths
            orchestrator = PipelineOrchestrator("1_pass_with_ontology")
            
            # Mock a simple run
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['Test question', 'Test context', '[]'])
            
            # Run with minimal questions
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Verify output path is in results_to_be_processed
            assert "results_to_be_processed" in output_path
            assert output_path.endswith('.csv')
            
            # Verify file was created
            assert os.path.exists(output_path)
            
        finally:
            os.chdir(original_cwd)


def test_csv_content_structure():
    """Test that CSV files have expected columns and structure."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['What is SAR?', 'SAR description', '[]'])
            
            # Run orchestrator
            orchestrator = PipelineOrchestrator("1_pass_with_ontology")
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Read and verify CSV content
            with open(output_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                fields = reader.fieldnames
                
                # Verify required columns
                required_columns = ['question_id', 'question', 'pipeline', 'answer', 'processing_time', 'status']
                for col in required_columns:
                    assert col in fields, f"Missing required column: {col}"
                
                # Verify at least one row of data
                rows = list(reader)
                assert len(rows) == 1
                assert rows[0]['question_id'] == '1'
                assert rows[0]['pipeline'] == '1_pass_with_ontology'
                assert rows[0]['status'] == 'success'
                
        finally:
            os.chdir(original_cwd)


def test_csv_no_duplicates():
    """Test that CSV utilities don't create duplicate entries."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['Question 1', 'Context 1', '[]'])
                writer.writerow(['Question 2', 'Context 2', '[]'])
            
            # First run
            orchestrator1 = PipelineOrchestrator("1_pass_with_ontology")
            results1, output_path1, stats1 = orchestrator1.run(
                input_csv=test_csv,
                num_questions=2,
                verbose=False
            )
            
            # Second run (should update, not duplicate)
            orchestrator2 = PipelineOrchestrator("1_pass_with_ontology")
            results2, output_path2, stats2 = orchestrator2.run(
                input_csv=test_csv,
                num_questions=2,
                verbose=False
            )
            
            # Verify same output path
            assert output_path1 == output_path2
            
            # Verify no duplicate rows
            with open(output_path1, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                # Should have exactly 2 rows (one per question), not 4
                assert len(rows) == 2
                
                # Verify unique question_ids
                question_ids = [row['question_id'] for row in rows]
                assert len(set(question_ids)) == 2  # No duplicates
                
        finally:
            os.chdir(original_cwd)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
