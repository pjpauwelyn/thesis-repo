# tests/unit/test_ontology_agent.py

import pytest
import json
import os
import sys

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'core'))

from unittest.mock import Mock, patch
from core.agents.ontology_agent import OntologyConstructionAgent
from core.utils.data_models import AttributeValuePair, LogicalRelationship, DynamicOntology


def test_ontology_extraction_structure():
    """Test that ontology extraction returns well-formed JSON structure with required categories and centrality scores."""
    
    # Create mock LLM that returns expected structure
    mock_llm = Mock()
    
    # Mock response for attribute extraction
    mock_llm.invoke.return_value = {
        'pairs': [
            {
                'attribute': 'technology',
                'value': 'SAR',
                'description': 'Synthetic Aperture Radar',
                'centrality': 0.95
            },
            {
                'attribute': 'application',
                'value': 'land cover mapping',
                'description': 'Mapping land cover types',
                'centrality': 0.85
            }
        ]
    }
    
    # Create agent with mock LLM
    agent = OntologyConstructionAgent(mock_llm, prompt_dir="tests/fixtures")
    
    # Mock the relationships call to return empty list
    with patch.object(agent, '_define_logical_relationships', return_value=[]):
        # Test ontology extraction
        question = "What are the main applications of SAR imagery?"
        ontology = agent.process(question)
        
        # Verify structure
        assert isinstance(ontology, DynamicOntology)
        assert ontology.source_query == question
        assert ontology.should_use_ontology == True
        
        # Verify attribute-value pairs
        assert len(ontology.attribute_value_pairs) == 2
        assert all(isinstance(av, AttributeValuePair) for av in ontology.attribute_value_pairs)
        
        # Verify centrality scores are in expected range
        for av in ontology.attribute_value_pairs:
            assert 0.0 <= av.centrality <= 1.0
            assert hasattr(av, 'attribute') and av.attribute
            assert hasattr(av, 'value') and av.value
            assert hasattr(av, 'description')


def test_ontology_relationships():
    """Test that logical relationships are properly defined."""
    
    # Create mock LLM
    mock_llm = Mock()
    
    # Mock attribute extraction
    mock_llm.invoke.side_effect = [
        {  # First call - attributes
            'pairs': [
                {
                    'attribute': 'technology',
                    'value': 'SAR',
                    'description': 'Synthetic Aperture Radar',
                    'centrality': 0.95
                }
            ]
        },
        {  # Second call - relationships
            'relationships': [
                {
                    'source_attribute': 'technology',
                    'source_value': 'SAR',
                    'target_attribute': 'advantage',
                    'target_value': 'cloud penetration',
                    'relationship_type': 'enables',
                    'logical_constraint': 'SAR enables cloud penetration'
                }
            ]
        }
    ]
    
    # Create agent
    agent = OntologyConstructionAgent(mock_llm, prompt_dir="tests/fixtures")
    
    # Test full ontology processing
    question = "What are SAR advantages?"
    ontology = agent.process(question)
    
    # Verify relationships
    assert len(ontology.logical_relationships) == 1
    assert all(isinstance(rel, LogicalRelationship) for rel in ontology.logical_relationships)
    
    relationship = ontology.logical_relationships[0]
    assert relationship.source_attribute == 'technology'
    assert relationship.source_value == 'SAR'
    assert relationship.relationship_type == 'enables'


def test_ontology_error_handling():
    """Test that ontology agent handles LLM errors gracefully."""
    
    # Create mock LLM that raises exception
    mock_llm = Mock()
    mock_llm.invoke.side_effect = Exception("LLM API error")
    
    # Create agent
    agent = OntologyConstructionAgent(mock_llm, prompt_dir="tests/fixtures")
    
    # Test with error handling
    question = "Test question"
    ontology = agent.process(question)
    
    # Should return empty ontology but not crash
    assert isinstance(ontology, DynamicOntology)
    assert ontology.source_query == question
    assert len(ontology.attribute_value_pairs) == 0
    assert len(ontology.logical_relationships) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
