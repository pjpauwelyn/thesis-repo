# tests/integration/test_end_to_end_workflows.py

import pytest
import os
import sys
import csv
import tempfile
from pathlib import Path

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'core'))

from core.main import PipelineOrchestrator


def test_1pass_with_ontology_workflow():
    """Test the 1-pass with ontology pipeline workflow."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input CSV
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['What are SAR applications?', 'SAR is a remote sensing technology.', '[]'])
            
            # Run 1-pass with ontology pipeline
            orchestrator = PipelineOrchestrator("1_pass_with_ontology")
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Verify workflow completed
            assert len(results) == 1
            assert results[0].status == "success"
            assert results[0].answer  # Answer should be generated
            
            # Verify CSV output
            assert os.path.exists(output_path)
            assert "results_to_be_processed" in output_path
            assert output_path.endswith('.csv')
            
            # Verify CSV content
            with open(output_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 1
                assert rows[0]['pipeline'] == '1_pass_with_ontology'
                assert rows[0]['status'] == 'success'
                
        finally:
            os.chdir(original_cwd)


def test_1pass_without_ontology_workflow():
    """Test the 1-pass without ontology pipeline workflow."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input CSV
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['What is NDVI?', 'NDVI measures vegetation health.', '[]'])
            
            # Run 1-pass without ontology pipeline
            orchestrator = PipelineOrchestrator("1_pass_without_ontology")
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Verify workflow completed
            assert len(results) == 1
            assert results[0].status == "success"
            assert results[0].answer
            
            # Verify CSV output
            assert os.path.exists(output_path)
            
            # Verify CSV content
            with open(output_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 1
                assert rows[0]['pipeline'] == '1_pass_without_ontology'
                
        finally:
            os.chdir(original_cwd)


def test_2pass_with_ontology_workflow():
    """Test the 2-pass with ontology pipeline workflow."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input CSV
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['How does optical imagery work?', 'Optical sensors capture visible light.', '[]'])
            
            # Run 2-pass with ontology pipeline
            orchestrator = PipelineOrchestrator("2_pass_with_ontology")
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Verify workflow completed
            assert len(results) == 1
            assert results[0].status == "success"
            assert results[0].answer
            
            # Verify CSV output
            assert os.path.exists(output_path)
            
            # Verify CSV content
            with open(output_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 1
                assert rows[0]['pipeline'] == '2_pass_with_ontology'
                
        finally:
            os.chdir(original_cwd)


def test_multiple_pipeline_workflow():
    """Test running multiple pipelines sequentially without conflicts."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input CSV
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['Question 1', 'Context 1', '[]'])
                writer.writerow(['Question 2', 'Context 2', '[]'])
            
            # Run multiple pipelines with different output files
            pipelines = [
                "1_pass_with_ontology",
                "1_pass_without_ontology", 
                "2_pass_with_ontology"
            ]
            
            output_paths = []
            for i, pipeline_type in enumerate(pipelines):
                # Use different output files for each pipeline
                output_file = f"test_output_{i}.csv"
                orchestrator = PipelineOrchestrator(pipeline_type)
                results, output_path, stats = orchestrator.run(
                    input_csv=test_csv,
                    num_questions=1,
                    output_dir=output_file,
                    verbose=False
                )
                output_paths.append(output_path)
                
                # Verify each run succeeded
                assert len(results) == 1
                assert results[0].status == "success"
            
            # Verify all pipelines created output
            assert all(os.path.exists(path) for path in output_paths)
            
            # Verify each CSV has correct pipeline type
            for i, pipeline_type in enumerate(pipelines):
                with open(output_paths[i], 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    rows = list(reader)
                    assert len(rows) == 1
                    assert rows[0]['pipeline'] == pipeline_type
                    
        finally:
            os.chdir(original_cwd)


def test_error_handling_in_workflow():
    """Test that workflows handle errors gracefully without crashing."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test input CSV with potentially problematic data
            test_csv = "test_questions.csv"
            with open(test_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question', 'structured_context', 'aql_results'])
                writer.writerow(['Very complex question that might cause issues?', 'Complex context.', '[]'])
            
            # Run pipeline - should handle gracefully even if LLM has issues
            orchestrator = PipelineOrchestrator("1_pass_with_ontology")
            results, output_path, stats = orchestrator.run(
                input_csv=test_csv,
                num_questions=1,
                verbose=False
            )
            
            # Should complete without crashing
            assert len(results) == 1
            # Status could be success or error, but should not crash
            assert results[0].status in ["success", "error"]
            
            # Should still create output file
            assert os.path.exists(output_path)
            
        finally:
            os.chdir(original_cwd)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
