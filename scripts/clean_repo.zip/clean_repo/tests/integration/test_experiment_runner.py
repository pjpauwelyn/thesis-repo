# tests/integration/test_experiment_runner.py

import pytest
import os
import sys
import csv
import tempfile
from pathlib import Path

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'experiments'))

from experiments.experiment_runner import ExperimentRunner


def test_slim_ontology_experiment():
    """Test the slim ontology experiment workflow."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create minimal test data CSV
            test_data_csv = "test_data.csv"
            with open(test_data_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question_id', 'question', 'structured_context', 'aql_results'])
                writer.writerow(['1', 'What is SAR?', 'SAR description', '[]'])
                writer.writerow(['2', 'What is NDVI?', 'NDVI description', '[]'])
            
            # Mock the data file path
            runner = ExperimentRunner("slim_ontology")
            
            # Replace the data file path with our test file
            runner.data_file = test_data_csv
            runner.csv_file = str(results_dir / "experiment_generation_results.csv")
            
            # Initialize CSV
            runner._initialize_csv()
            
            # Verify CSV was created with correct headers
            assert os.path.exists(runner.csv_file)
            
            with open(runner.csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames
                
                # Verify required headers
                required_headers = ['question_id', 'question', 'pipeline', 'answer', 'experiment_type']
                for header in required_headers:
                    assert header in headers, f"Missing required header: {header}"
            
        finally:
            os.chdir(original_cwd)


def test_scores_only_experiment():
    """Test the scores-only experiment workflow."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create minimal test data CSV
            test_data_csv = "test_data.csv"
            with open(test_data_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question_id', 'question', 'structured_context', 'aql_results'])
                writer.writerow(['1', 'Test question', 'Test context', '[]'])
            
            # Create scores-only experiment runner
            runner = ExperimentRunner("scores_only")
            
            # Replace the data file path with our test file
            runner.data_file = test_data_csv
            runner.csv_file = str(results_dir / "experiment_generation_results.csv")
            
            # Initialize CSV
            runner._initialize_csv()
            
            # Verify CSV was created
            assert os.path.exists(runner.csv_file)
            
            # Verify configuration
            config = runner._get_pipeline_config()
            assert config['pipeline_type'] == '1_pass_with_ontology'
            assert config['use_dlr_compatible'] == True
            assert config['description'] == 'Scores-Only Experiment'
            
        finally:
            os.chdir(original_cwd)


def test_experiment_csv_structure():
    """Test that experiment runner creates CSV with correct structure."""
    
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            
            # Create test setup
            results_dir = Path("results_to_be_processed")
            results_dir.mkdir(exist_ok=True)
            
            # Create test data CSV
            test_data_csv = "test_data.csv"
            with open(test_data_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['question_id', 'question', 'structured_context', 'aql_results'])
                writer.writerow(['1', 'Test question', 'Test context', '[]'])
            
            # Create experiment runner
            runner = ExperimentRunner("slim_ontology")
            runner.data_file = test_data_csv
            runner.csv_file = str(results_dir / "experiment_generation_results.csv")
            
            # Initialize CSV
            runner._initialize_csv()
            
            # Read and verify CSV structure
            with open(runner.csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames
                
                # Verify experiment-specific headers
                experiment_headers = ['ontology_attributes', 'ontology_relationships', 'ontology_should_use']
                for header in experiment_headers:
                    assert header in headers, f"Missing experiment header: {header}"
                
                # Verify standard headers
                standard_headers = ['question_id', 'question', 'pipeline', 'answer', 'processing_time']
                for header in standard_headers:
                    assert header in headers, f"Missing standard header: {header}"
            
        finally:
            os.chdir(original_cwd)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
