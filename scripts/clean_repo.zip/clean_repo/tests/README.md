# Test Suite for Multi-Agent Ontology RAG System

## Overview

This test suite provides lightweight but effective verification of the main workflows and wiring of the system. The tests are designed to verify code paths, imports, and basic logic without requiring all external APIs to succeed on every run.

## Test Structure

```
tests/
├── unit/                  # Unit-style tests for individual components
├── integration/          # Integration-style tests for main workflows
└── fixtures/             # Test fixtures and mock data
```

## Running Tests

### Unit Tests
Run all unit tests:
```bash
pytest tests/unit/
```

### Integration Tests
Run all integration tests:
```bash
pytest tests/integration/
```

### All Tests
Run the complete test suite:
```bash
pytest tests/
```

## Test Coverage

### Unit Tests
- **Ontology Agent**: Validates ontology extraction function returns well-formed JSON structure
- **Refinement Agent**: Tests relevance scoring and usage guidance generation
- **Generation Agent**: Verifies answer structure and formatting
- **CSV Utilities**: Tests path handling and CSV operations

### Integration Tests
- **End-to-End Workflows**: Tests the four main pipeline variants
- **CSV Verification**: Confirms standardized result CSVs are created/updated correctly
- **Error Handling**: Verifies graceful handling of API failures

## Environment Requirements

For tests that require API access:
- Set `OPENAI_API_KEY` in `.env` file
- Set `MISTRAL_API_KEY` in `.env` file

## Known Limitations

1. **API Dependencies**: Some integration tests may fail if external APIs are unavailable
2. **Mock Coverage**: Not all external dependencies are fully mocked
3. **Performance Testing**: No load/performance tests included

## Extending Tests

To add new tests:
1. Place unit tests in `tests/unit/` with `test_*.py` naming
2. Place integration tests in `tests/integration/` with `test_*.py` naming
3. Add fixtures to `tests/fixtures/` as needed
4. Update this README to document new test coverage
