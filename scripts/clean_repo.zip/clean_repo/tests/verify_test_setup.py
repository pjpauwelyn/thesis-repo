#!/usr/bin/env python3
"""
Test setup verification script.

This script demonstrates that the test suite is properly configured and can verify
the main workflows of the Multi-Agent Ontology RAG System.
"""

import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and return success status."""
    print(f"\n🧪 {description}")
    print(f"📋 Command: {command}")
    
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            cwd="/Users/pjpauwelyn/THESIS_2025/thesis-rep"
        )
        
        if result.returncode == 0:
            print(f"✅ SUCCESS")
            return True
        else:
            print(f"❌ FAILED")
            print(f"Error: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ ERROR: {e}")
        return False

def main():
    """Main verification function."""
    print("🔍 Multi-Agent Ontology RAG System - Test Setup Verification")
    print("=" * 60)
    
    tests_passed = 0
    total_tests = 6
    
    # Test 1: Unit tests - Ontology Agent
    if run_command("python -m pytest tests/unit/test_ontology_agent.py -v --tb=short", 
                   "Unit Tests - Ontology Agent"):
        tests_passed += 1
    
    # Test 2: Unit tests - CSV Utilities
    if run_command("python -m pytest tests/unit/test_csv_utils.py -v --tb=short", 
                   "Unit Tests - CSV Utilities"):
        tests_passed += 1
    
    # Test 3: Integration tests - End-to-End Workflows
    if run_command("python -m pytest tests/integration/test_end_to_end_workflows.py -v --tb=short", 
                   "Integration Tests - End-to-End Workflows"):
        tests_passed += 1
    
    # Test 4: Integration tests - Experiment Runner
    if run_command("python -m pytest tests/integration/test_experiment_runner.py -v --tb=short", 
                   "Integration Tests - Experiment Runner"):
        tests_passed += 1
    
    # Test 5: All unit tests
    if run_command("python -m pytest tests/unit/ -v --tb=short", 
                   "All Unit Tests"):
        tests_passed += 1
    
    # Test 6: All integration tests
    if run_command("python -m pytest tests/integration/ -v --tb=short", 
                   "All Integration Tests"):
        tests_passed += 1
    
    # Summary
    print(f"\n" + "=" * 60)
    print(f"📊 VERIFICATION SUMMARY")
    print(f"🎯 Tests Passed: {tests_passed}/{total_tests}")
    
    if tests_passed == total_tests:
        print(f"🎉 ALL TESTS PASSED! Test setup is working correctly.")
        print(f"\n✅ The test suite successfully verifies:")
        print(f"   • Core component functionality (ontology agent, CSV utils)")
        print(f"   • End-to-end workflows for all pipeline variants")
        print(f"   • Experiment runner configurations")
        print(f"   • CSV handling and path management")
        print(f"   • Error handling and graceful degradation")
        return 0
    else:
        print(f"⚠️  Some tests failed. Please check the error messages above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
